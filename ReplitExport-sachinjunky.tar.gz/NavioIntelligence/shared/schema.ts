import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
});

// User profile schema
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  education: jsonb("education"),
  experience: jsonb("experience"),
  skills: jsonb("skills"),
  goals: text("goals"),
  profileCompleted: boolean("profile_completed").default(false),
  personalityResult: jsonb("personality_result"),
});

export const insertProfileSchema = createInsertSchema(profiles).pick({
  userId: true,
  education: true,
  experience: true,
  skills: true,
  goals: true,
  profileCompleted: true,
  personalityResult: true,
});

// Resume schema
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  filename: text("filename").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
  analysis: jsonb("analysis"),
});

export const insertResumeSchema = createInsertSchema(resumes).pick({
  userId: true,
  filename: true,
  analysis: true,
});

// Career path schema
export const careerPaths = pgTable("career_paths", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  skillsRequired: jsonb("skills_required").notNull(),
  avgSalary: text("avg_salary"),
  hiringTrend: text("hiring_trend"),
  yoyGrowth: text("yoy_growth"),
  jobListings: text("job_listings"),
  pandumpsScore: jsonb("pandumps_score").notNull(),
});

export const insertCareerPathSchema = createInsertSchema(careerPaths);

// User career matches schema
export const userCareerMatches = pgTable("user_career_matches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  careerPathId: integer("career_path_id").notNull().references(() => careerPaths.id),
  matchScore: integer("match_score").notNull(),
  skillsMatch: jsonb("skills_match").notNull(),
  gapAnalysis: jsonb("gap_analysis"),
  isSaved: boolean("is_saved").default(false),
});

export const insertUserCareerMatchSchema = createInsertSchema(userCareerMatches).pick({
  userId: true,
  careerPathId: true,
  matchScore: true,
  skillsMatch: true,
  gapAnalysis: true,
  isSaved: true,
});

// Interview sessions schema
export const interviewSessions = pgTable("interview_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  interviewType: text("interview_type").notNull(),
  careerPath: text("career_path"),
  scheduledAt: timestamp("scheduled_at"),
  completedAt: timestamp("completed_at"),
  feedback: jsonb("feedback"),
});

export const insertInterviewSessionSchema = createInsertSchema(interviewSessions).pick({
  userId: true,
  interviewType: true,
  careerPath: true,
  scheduledAt: true,
  completedAt: true,
  feedback: true,
});

// Define the types that will be used in the application
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = z.infer<typeof insertProfileSchema>;

export type Resume = typeof resumes.$inferSelect;
export type InsertResume = z.infer<typeof insertResumeSchema>;

export type CareerPath = typeof careerPaths.$inferSelect;
export type InsertCareerPath = z.infer<typeof insertCareerPathSchema>;

export type UserCareerMatch = typeof userCareerMatches.$inferSelect;
export type InsertUserCareerMatch = z.infer<typeof insertUserCareerMatchSchema>;

export type InterviewSession = typeof interviewSessions.$inferSelect;
export type InsertInterviewSession = z.infer<typeof insertInterviewSessionSchema>;
