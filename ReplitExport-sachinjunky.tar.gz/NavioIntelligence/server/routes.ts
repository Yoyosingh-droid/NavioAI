import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { 
  analyzeResume, 
  suggestCareerPaths, 
  analyzePersonality, 
  generateInterviewQuestions, 
  evaluateInterviewAnswer,
  analyzeSkillGaps
} from "./openai";
import { insertProfileSchema, insertResumeSchema } from "@shared/schema";

// Configure multer for file upload
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, '../uploads');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  fileFilter: (req, file, cb) => {
    const filetypes = /pdf|docx/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only PDF and DOCX files are allowed'));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB
  }
});

// Auth middleware for protected routes
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Initialize career paths in the database
  await storage.initCareerPaths();
  
  // Profile routes
  app.get('/api/profile', isAuthenticated, async (req, res) => {
    try {
      const profile = await storage.getProfile(req.user.id);
      res.json(profile || { userId: req.user.id, profileCompleted: false });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });
  
  app.post('/api/profile', isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertProfileSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const existingProfile = await storage.getProfile(req.user.id);
      
      let profile;
      if (existingProfile) {
        profile = await storage.updateProfile(req.user.id, validatedData);
      } else {
        profile = await storage.createProfile(validatedData);
      }
      
      res.status(201).json(profile);
    } catch (error) {
      res.status(400).json({ message: "Invalid profile data", error: error.message });
    }
  });
  
  // Resume upload and analysis
  app.post('/api/resume/upload', isAuthenticated, upload.single('resume'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // For a real implementation, we would extract text from the PDF/DOCX here
      // For this MVP, we'll simulate having the resume text
      const resumeText = "Sample resume text for analysis";
      
      // Analyze the resume using OpenAI
      const analysis = await analyzeResume(resumeText);
      
      // Save the resume to storage
      const resume = await storage.createResume({
        userId: req.user.id,
        filename: req.file.filename,
        analysis
      });
      
      res.status(201).json(resume);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload and analyze resume", error: error.message });
    }
  });
  
  app.get('/api/resume/list', isAuthenticated, async (req, res) => {
    try {
      const resumes = await storage.getResumes(req.user.id);
      res.json(resumes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resumes" });
    }
  });
  
  app.get('/api/resume/:id', isAuthenticated, async (req, res) => {
    try {
      const resumeId = parseInt(req.params.id);
      const resume = await storage.getResumeById(resumeId);
      
      if (!resume) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      if (resume.userId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(resume);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resume" });
    }
  });
  
  // Career paths
  app.get('/api/career-paths', isAuthenticated, async (req, res) => {
    try {
      const careerPaths = await storage.getCareerPaths();
      res.json(careerPaths);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch career paths" });
    }
  });
  
  app.get('/api/career-paths/:id', isAuthenticated, async (req, res) => {
    try {
      const careerPathId = parseInt(req.params.id);
      const careerPath = await storage.getCareerPathById(careerPathId);
      
      if (!careerPath) {
        return res.status(404).json({ message: "Career path not found" });
      }
      
      res.json(careerPath);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch career path" });
    }
  });
  
  // User career matches
  app.get('/api/career-matches', isAuthenticated, async (req, res) => {
    try {
      const matches = await storage.getUserCareerMatches(req.user.id);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch career matches" });
    }
  });
  
  app.post('/api/career-matches/:careerPathId/toggle-save', isAuthenticated, async (req, res) => {
    try {
      const careerPathId = parseInt(req.params.careerPathId);
      const matches = await storage.getUserCareerMatches(req.user.id);
      const match = matches.find(m => m.careerPathId === careerPathId);
      
      if (!match) {
        return res.status(404).json({ message: "Career match not found" });
      }
      
      const updatedMatch = await storage.updateUserCareerMatch(match.id, {
        isSaved: !match.isSaved
      });
      
      res.json(updatedMatch);
    } catch (error) {
      res.status(500).json({ message: "Failed to update career match" });
    }
  });
  
  // Analyze skill gaps
  app.post('/api/analyze-skill-gaps', isAuthenticated, async (req, res) => {
    try {
      const { userSkills, careerPathId } = req.body;
      
      if (!userSkills || !careerPathId) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const careerPath = await storage.getCareerPathById(parseInt(careerPathId));
      if (!careerPath) {
        return res.status(404).json({ message: "Career path not found" });
      }
      
      const analysis = await analyzeSkillGaps(userSkills, careerPath.skillsRequired);
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze skill gaps", error: error.message });
    }
  });
  
  // Personality quiz
  app.post('/api/personality-quiz', isAuthenticated, async (req, res) => {
    try {
      const { responses } = req.body;
      
      if (!responses) {
        return res.status(400).json({ message: "Missing quiz responses" });
      }
      
      const analysisResult = await analyzePersonality(responses);
      
      // Update the user's profile with the personality results
      const existingProfile = await storage.getProfile(req.user.id);
      
      if (existingProfile) {
        await storage.updateProfile(req.user.id, {
          ...existingProfile,
          personalityResult: analysisResult
        });
      } else {
        await storage.createProfile({
          userId: req.user.id,
          personalityResult: analysisResult,
          profileCompleted: false
        });
      }
      
      res.json(analysisResult);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze personality quiz", error: error.message });
    }
  });
  
  // Interview practice
  app.get('/api/interview-sessions', isAuthenticated, async (req, res) => {
    try {
      const sessions = await storage.getInterviewSessions(req.user.id);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch interview sessions" });
    }
  });
  
  app.post('/api/interview-sessions', isAuthenticated, async (req, res) => {
    try {
      const { interviewType, careerPath, scheduledAt } = req.body;
      
      const session = await storage.createInterviewSession({
        userId: req.user.id,
        interviewType,
        careerPath,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : undefined
      });
      
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ message: "Failed to create interview session", error: error.message });
    }
  });
  
  app.get('/api/interview-questions', isAuthenticated, async (req, res) => {
    try {
      const { careerPath, interviewType } = req.query;
      
      if (!careerPath || !interviewType) {
        return res.status(400).json({ message: "Missing required parameters" });
      }
      
      const questions = await generateInterviewQuestions(
        careerPath as string, 
        interviewType as string
      );
      
      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate interview questions", error: error.message });
    }
  });
  
  app.post('/api/evaluate-answer', isAuthenticated, async (req, res) => {
    try {
      const { question, answer, careerPath } = req.body;
      
      if (!question || !answer || !careerPath) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      const evaluation = await evaluateInterviewAnswer(question, answer, careerPath);
      res.json(evaluation);
    } catch (error) {
      res.status(500).json({ message: "Failed to evaluate answer", error: error.message });
    }
  });
  
  app.post('/api/interview-sessions/:id/complete', isAuthenticated, async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { feedback } = req.body;
      
      const session = await storage.getInterviewSessionById(sessionId);
      
      if (!session) {
        return res.status(404).json({ message: "Interview session not found" });
      }
      
      if (session.userId !== req.user.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const updatedSession = await storage.updateInterviewSession(sessionId, {
        completedAt: new Date(),
        feedback
      });
      
      res.json(updatedSession);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete interview session", error: error.message });
    }
  });
  
  // Suggest career paths based on user profile
  app.get('/api/suggest-careers', isAuthenticated, async (req, res) => {
    try {
      const profile = await storage.getProfile(req.user.id);
      
      if (!profile) {
        return res.status(400).json({ message: "Profile not found. Please complete your profile first." });
      }
      
      const suggestions = await suggestCareerPaths(profile);
      
      // For each suggested career, create a user-career match if it doesn't exist
      const careerPaths = await storage.getCareerPaths();
      const userMatches = await storage.getUserCareerMatches(req.user.id);
      
      for (const suggestedCareer of suggestions.suggestedCareers) {
        const careerPath = careerPaths.find(cp => cp.title.toLowerCase() === suggestedCareer.toLowerCase());
        
        if (careerPath && !userMatches.some(m => m.careerPathId === careerPath.id)) {
          // Calculate a mock match score
          const matchScore = Math.floor(Math.random() * (95 - 70 + 1)) + 70;
          
          // Create skill match percentages
          const skillsMatch = {};
          Object.keys(careerPath.skillsRequired).forEach(skill => {
            skillsMatch[skill] = Math.floor(Math.random() * (95 - 60 + 1)) + 60;
          });
          
          // Create gap analysis
          const gapAnalysis = [
            "Advanced certification",
            "Industry experience",
            "Technical skill improvement"
          ];
          
          await storage.createUserCareerMatch({
            userId: req.user.id,
            careerPathId: careerPath.id,
            matchScore,
            skillsMatch,
            gapAnalysis,
            isSaved: false
          });
        }
      }
      
      const updatedMatches = await storage.getUserCareerMatches(req.user.id);
      res.json(updatedMatches);
    } catch (error) {
      res.status(500).json({ message: "Failed to suggest careers", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
