import { users, profiles, resumes, careerPaths, userCareerMatches, interviewSessions } from "@shared/schema";
import type { 
  User, Profile, Resume, CareerPath, UserCareerMatch, 
  InterviewSession, InsertUser, InsertProfile, InsertResume, 
  InsertCareerPath, InsertUserCareerMatch, InsertInterviewSession 
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { db, pool } from "./db";
import { eq, and } from "drizzle-orm";
import connectPg from "connect-pg-simple";

const PostgresSessionStore = connectPg(session);
const MemoryStore = createMemoryStore(session);

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Profile methods
  getProfile(userId: number): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(userId: number, data: Partial<InsertProfile>): Promise<Profile>;

  // Resume methods
  getResumes(userId: number): Promise<Resume[]>;
  getResumeById(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResumeAnalysis(id: number, analysis: any): Promise<Resume>;

  // Career path methods
  getCareerPaths(): Promise<CareerPath[]>;
  getCareerPathById(id: number): Promise<CareerPath | undefined>;
  createCareerPath(careerPath: InsertCareerPath): Promise<CareerPath>;
  initCareerPaths(): Promise<void>;

  // User career match methods
  getUserCareerMatches(userId: number): Promise<(UserCareerMatch & { careerPath: CareerPath })[]>;
  createUserCareerMatch(match: InsertUserCareerMatch): Promise<UserCareerMatch>;
  updateUserCareerMatch(id: number, data: Partial<InsertUserCareerMatch>): Promise<UserCareerMatch>;

  // Interview session methods
  getInterviewSessions(userId: number): Promise<InterviewSession[]>;
  getInterviewSessionById(id: number): Promise<InterviewSession | undefined>;
  createInterviewSession(session: InsertInterviewSession): Promise<InterviewSession>;
  updateInterviewSession(id: number, data: Partial<InsertInterviewSession>): Promise<InterviewSession>;

  // Session store for authentication
  sessionStore: any; // Express session store
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private profiles: Map<number, Profile>;
  private resumes: Map<number, Resume>;
  private careerPaths: Map<number, CareerPath>;
  private userCareerMatches: Map<number, UserCareerMatch>;
  private interviewSessions: Map<number, InterviewSession>;
  
  sessionStore: session.SessionStore;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.profiles = new Map();
    this.resumes = new Map();
    this.careerPaths = new Map();
    this.userCareerMatches = new Map();
    this.interviewSessions = new Map();
    this.currentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Initialize the career paths (async init is handled outside constructor)
    void this.initCareerPaths();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  // Profile methods
  async getProfile(userId: number): Promise<Profile | undefined> {
    return Array.from(this.profiles.values()).find(
      (profile) => profile.userId === userId,
    );
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const id = this.currentId++;
    const newProfile: Profile = { ...profile, id };
    this.profiles.set(id, newProfile);
    return newProfile;
  }

  async updateProfile(userId: number, data: Partial<InsertProfile>): Promise<Profile> {
    const profile = await this.getProfile(userId);
    if (!profile) {
      throw new Error("Profile not found");
    }
    
    const updatedProfile = { ...profile, ...data };
    this.profiles.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  // Resume methods
  async getResumes(userId: number): Promise<Resume[]> {
    return Array.from(this.resumes.values()).filter(
      (resume) => resume.userId === userId,
    );
  }

  async getResumeById(id: number): Promise<Resume | undefined> {
    return this.resumes.get(id);
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    const id = this.currentId++;
    const uploadedAt = new Date();
    const newResume: Resume = { ...resume, id, uploadedAt };
    this.resumes.set(id, newResume);
    return newResume;
  }

  async updateResumeAnalysis(id: number, analysis: any): Promise<Resume> {
    const resume = await this.getResumeById(id);
    if (!resume) {
      throw new Error("Resume not found");
    }
    
    const updatedResume = { ...resume, analysis };
    this.resumes.set(id, updatedResume);
    return updatedResume;
  }

  // Career path methods
  async getCareerPaths(): Promise<CareerPath[]> {
    return Array.from(this.careerPaths.values());
  }

  async getCareerPathById(id: number): Promise<CareerPath | undefined> {
    return this.careerPaths.get(id);
  }

  async createCareerPath(careerPath: InsertCareerPath): Promise<CareerPath> {
    const id = this.currentId++;
    const newCareerPath: CareerPath = { ...careerPath, id };
    this.careerPaths.set(id, newCareerPath);
    return newCareerPath;
  }

  // User career match methods
  async getUserCareerMatches(userId: number): Promise<(UserCareerMatch & { careerPath: CareerPath })[]> {
    const matches = Array.from(this.userCareerMatches.values()).filter(
      (match) => match.userId === userId,
    );
    
    // Join with career paths
    return matches.map(match => {
      const careerPath = this.careerPaths.get(match.careerPathId);
      if (!careerPath) throw new Error(`Career path with ID ${match.careerPathId} not found`);
      return { ...match, careerPath };
    });
  }

  async createUserCareerMatch(match: InsertUserCareerMatch): Promise<UserCareerMatch> {
    const id = this.currentId++;
    const newMatch: UserCareerMatch = { ...match, id };
    this.userCareerMatches.set(id, newMatch);
    return newMatch;
  }

  async updateUserCareerMatch(id: number, data: Partial<InsertUserCareerMatch>): Promise<UserCareerMatch> {
    const match = this.userCareerMatches.get(id);
    if (!match) {
      throw new Error("User career match not found");
    }
    
    const updatedMatch = { ...match, ...data };
    this.userCareerMatches.set(id, updatedMatch);
    return updatedMatch;
  }

  // Interview session methods
  async getInterviewSessions(userId: number): Promise<InterviewSession[]> {
    return Array.from(this.interviewSessions.values()).filter(
      (session) => session.userId === userId,
    );
  }

  async getInterviewSessionById(id: number): Promise<InterviewSession | undefined> {
    return this.interviewSessions.get(id);
  }

  async createInterviewSession(session: InsertInterviewSession): Promise<InterviewSession> {
    const id = this.currentId++;
    const newSession: InterviewSession = { ...session, id };
    this.interviewSessions.set(id, newSession);
    return newSession;
  }

  async updateInterviewSession(id: number, data: Partial<InsertInterviewSession>): Promise<InterviewSession> {
    const session = await this.getInterviewSessionById(id);
    if (!session) {
      throw new Error("Interview session not found");
    }
    
    const updatedSession = { ...session, ...data };
    this.interviewSessions.set(id, updatedSession);
    return updatedSession;
  }

  // Initialize some sample career paths data
  async initCareerPaths(): Promise<void> {
    const careerPathsData: InsertCareerPath[] = [
      {
        title: "UX/UI Designer",
        description: "Designing user experiences and interfaces for digital products",
        skillsRequired: {
          "Visual Design": 95,
          "User Research": 82,
          "Prototyping": 78,
          "Interaction Design": 65
        },
        avgSalary: "$85k-105k",
        hiringTrend: "+12%",
        yoyGrowth: "+8.2%",
        jobListings: "2,450+",
        pandumpsScore: {
          current: 7.2,
          history: [6.8, 7.0, 7.2]
        }
      },
      {
        title: "Data Analyst",
        description: "Interpreting data to drive business decisions and insights",
        skillsRequired: {
          "Data Visualization": 88,
          "Excel/Spreadsheets": 90,
          "SQL": 62,
          "Statistical Analysis": 70
        },
        avgSalary: "$75k-95k",
        hiringTrend: "+15%",
        yoyGrowth: "+7.5%",
        jobListings: "3,120+",
        pandumpsScore: {
          current: 6.8,
          history: [6.2, 6.5, 6.8]
        }
      },
      {
        title: "Full Stack Developer",
        description: "Building and maintaining complete web applications",
        skillsRequired: {
          "JavaScript": 90,
          "React": 85,
          "Node.js": 80,
          "Database Management": 75
        },
        avgSalary: "$90k-120k",
        hiringTrend: "+18%",
        yoyGrowth: "+10.2%",
        jobListings: "5,200+",
        pandumpsScore: {
          current: 7.5,
          history: [7.0, 7.2, 7.5]
        }
      },
      {
        title: "Product Manager",
        description: "Overseeing product development and strategy",
        skillsRequired: {
          "Strategic Planning": 85,
          "Market Research": 80,
          "Team Leadership": 75,
          "Technical Knowledge": 65
        },
        avgSalary: "$100k-130k",
        hiringTrend: "+10%",
        yoyGrowth: "+6.8%",
        jobListings: "1,850+",
        pandumpsScore: {
          current: 6.9,
          history: [6.5, 6.7, 6.9]
        }
      },
      {
        title: "AI Researcher",
        description: "Developing and implementing artificial intelligence solutions",
        skillsRequired: {
          "Machine Learning": 95,
          "Python": 90,
          "Statistics": 85,
          "Mathematics": 80
        },
        avgSalary: "$110k-150k",
        hiringTrend: "+25%",
        yoyGrowth: "+15.2%",
        jobListings: "1,200+",
        pandumpsScore: {
          current: 7.8,
          history: [7.0, 7.5, 7.8]
        }
      }
    ];

    careerPathsData.forEach(careerPath => {
      this.createCareerPath(careerPath);
    });
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: any; // Express session store

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [createdUser] = await db.insert(users).values(user).returning();
    return createdUser;
  }

  // Profile methods
  async getProfile(userId: number): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.userId, userId));
    return profile || undefined;
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const [createdProfile] = await db.insert(profiles).values(profile).returning();
    return createdProfile;
  }

  async updateProfile(userId: number, data: Partial<InsertProfile>): Promise<Profile> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.userId, userId));
    
    if (!profile) {
      throw new Error("Profile not found");
    }
    
    const [updatedProfile] = await db
      .update(profiles)
      .set(data)
      .where(eq(profiles.userId, userId))
      .returning();
      
    return updatedProfile;
  }

  // Resume methods
  async getResumes(userId: number): Promise<Resume[]> {
    return await db.select().from(resumes).where(eq(resumes.userId, userId));
  }

  async getResumeById(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume || undefined;
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    const [createdResume] = await db.insert(resumes).values(resume).returning();
    return createdResume;
  }

  async updateResumeAnalysis(id: number, analysis: any): Promise<Resume> {
    const [updatedResume] = await db
      .update(resumes)
      .set({ analysis })
      .where(eq(resumes.id, id))
      .returning();
      
    if (!updatedResume) {
      throw new Error("Resume not found");
    }
    
    return updatedResume;
  }

  // Career path methods
  async getCareerPaths(): Promise<CareerPath[]> {
    return await db.select().from(careerPaths);
  }

  async getCareerPathById(id: number): Promise<CareerPath | undefined> {
    const [careerPath] = await db.select().from(careerPaths).where(eq(careerPaths.id, id));
    return careerPath || undefined;
  }

  async createCareerPath(careerPath: InsertCareerPath): Promise<CareerPath> {
    const [createdCareerPath] = await db.insert(careerPaths).values(careerPath).returning();
    return createdCareerPath;
  }

  // User career match methods
  async getUserCareerMatches(userId: number): Promise<(UserCareerMatch & { careerPath: CareerPath })[]> {
    const matches = await db
      .select({
        match: userCareerMatches,
        careerPath: careerPaths
      })
      .from(userCareerMatches)
      .innerJoin(careerPaths, eq(userCareerMatches.careerPathId, careerPaths.id))
      .where(eq(userCareerMatches.userId, userId));
      
    return matches.map(({ match, careerPath }) => ({ ...match, careerPath }));
  }

  async createUserCareerMatch(match: InsertUserCareerMatch): Promise<UserCareerMatch> {
    const [createdMatch] = await db.insert(userCareerMatches).values(match).returning();
    return createdMatch;
  }

  async updateUserCareerMatch(id: number, data: Partial<InsertUserCareerMatch>): Promise<UserCareerMatch> {
    const [updatedMatch] = await db
      .update(userCareerMatches)
      .set(data)
      .where(eq(userCareerMatches.id, id))
      .returning();
      
    if (!updatedMatch) {
      throw new Error("User career match not found");
    }
    
    return updatedMatch;
  }

  // Interview session methods
  async getInterviewSessions(userId: number): Promise<InterviewSession[]> {
    return await db.select().from(interviewSessions).where(eq(interviewSessions.userId, userId));
  }

  async getInterviewSessionById(id: number): Promise<InterviewSession | undefined> {
    const [session] = await db.select().from(interviewSessions).where(eq(interviewSessions.id, id));
    return session || undefined;
  }

  async createInterviewSession(session: InsertInterviewSession): Promise<InterviewSession> {
    const [createdSession] = await db.insert(interviewSessions).values(session).returning();
    return createdSession;
  }

  async updateInterviewSession(id: number, data: Partial<InsertInterviewSession>): Promise<InterviewSession> {
    const [updatedSession] = await db
      .update(interviewSessions)
      .set(data)
      .where(eq(interviewSessions.id, id))
      .returning();
      
    if (!updatedSession) {
      throw new Error("Interview session not found");
    }
    
    return updatedSession;
  }

  // Initialize career paths
  async initCareerPaths() {
    const existingPaths = await this.getCareerPaths();
    
    if (existingPaths.length === 0) {
      const careerPathsData: InsertCareerPath[] = [
        {
          title: "UX/UI Designer",
          description: "Designing user experiences and interfaces for digital products",
          skillsRequired: {
            "Visual Design": 95,
            "User Research": 82,
            "Prototyping": 78,
            "Interaction Design": 65
          },
          avgSalary: "$85k-105k",
          hiringTrend: "+12%",
          yoyGrowth: "+8.2%",
          jobListings: "2,450+",
          pandumpsScore: {
            current: 7.2,
            history: [6.8, 7.0, 7.2]
          }
        },
        {
          title: "Data Analyst",
          description: "Interpreting data to drive business decisions and insights",
          skillsRequired: {
            "Data Visualization": 88,
            "Excel/Spreadsheets": 90,
            "SQL": 62,
            "Statistical Analysis": 70
          },
          avgSalary: "$75k-95k",
          hiringTrend: "+15%",
          yoyGrowth: "+7.5%",
          jobListings: "3,120+",
          pandumpsScore: {
            current: 6.8,
            history: [6.2, 6.5, 6.8]
          }
        },
        {
          title: "Full Stack Developer",
          description: "Building and maintaining complete web applications",
          skillsRequired: {
            "JavaScript": 90,
            "React": 85,
            "Node.js": 80,
            "Database Management": 75
          },
          avgSalary: "$90k-120k",
          hiringTrend: "+18%",
          yoyGrowth: "+10.2%",
          jobListings: "5,200+",
          pandumpsScore: {
            current: 7.5,
            history: [7.0, 7.2, 7.5]
          }
        },
        {
          title: "Product Manager",
          description: "Overseeing product development and strategy",
          skillsRequired: {
            "Strategic Planning": 85,
            "Market Research": 80,
            "Team Leadership": 75,
            "Technical Knowledge": 65
          },
          avgSalary: "$100k-130k",
          hiringTrend: "+10%",
          yoyGrowth: "+6.8%",
          jobListings: "1,850+",
          pandumpsScore: {
            current: 6.9,
            history: [6.5, 6.7, 6.9]
          }
        },
        {
          title: "AI Researcher",
          description: "Developing and implementing artificial intelligence solutions",
          skillsRequired: {
            "Machine Learning": 95,
            "Python": 90,
            "Statistics": 85,
            "Mathematics": 80
          },
          avgSalary: "$110k-150k",
          hiringTrend: "+25%",
          yoyGrowth: "+15.2%",
          jobListings: "1,200+",
          pandumpsScore: {
            current: 7.8,
            history: [7.0, 7.5, 7.8]
          }
        }
      ];

      for (const careerPath of careerPathsData) {
        await this.createCareerPath(careerPath);
      }
    }
  }
}

export const storage = new DatabaseStorage();
