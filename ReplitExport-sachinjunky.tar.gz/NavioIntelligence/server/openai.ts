import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Analyze resume and provide feedback
export async function analyzeResume(resumeText: string): Promise<{
  strengths: string[];
  improvementAreas: string[];
  skillsIdentified: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a career coach analyzing a resume. Provide constructive feedback in JSON format with these keys: 'strengths' (array of strengths), 'improvementAreas' (array of improvement areas), and 'skillsIdentified' (array of skills identified).",
        },
        {
          role: "user",
          content: resumeText,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Resume analysis error:", error);
    throw new Error("Failed to analyze resume");
  }
}

// Analyze user profile and suggest career paths
export async function suggestCareerPaths(userProfile: any): Promise<{
  suggestedCareers: string[];
  reasoning: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a career advisor. Based on the user's profile, suggest suitable career paths. Respond with JSON in this format: { 'suggestedCareers': [array of career titles], 'reasoning': string explanation }",
        },
        {
          role: "user",
          content: JSON.stringify(userProfile),
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Career suggestion error:", error);
    throw new Error("Failed to suggest career paths");
  }
}

// Analyze personality quiz responses
export async function analyzePersonality(quizResponses: any): Promise<{
  personalityType: string;
  strengths: string[];
  workStyle: string;
  idealEnvironment: string;
  careerSuggestions: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a personality assessment expert. Analyze the quiz responses and provide insights about the user's professional personality. Respond with JSON in this format: { 'personalityType': string, 'strengths': [array of strengths], 'workStyle': string, 'idealEnvironment': string, 'careerSuggestions': [array of career suggestions] }",
        },
        {
          role: "user",
          content: JSON.stringify(quizResponses),
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Personality analysis error:", error);
    throw new Error("Failed to analyze personality");
  }
}

// Generate interview questions for practice
export async function generateInterviewQuestions(careerPath: string, interviewType: string): Promise<{
  questions: Array<{ question: string; context: string; }>;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are an interview coach. Generate realistic interview questions for the specified career path and interview type. For each question, provide some context about why this question might be asked. Respond with JSON in this format: { 'questions': [{ 'question': string, 'context': string }] }",
        },
        {
          role: "user",
          content: `Career Path: ${careerPath}, Interview Type: ${interviewType}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Interview questions error:", error);
    throw new Error("Failed to generate interview questions");
  }
}

// Evaluate interview answer
export async function evaluateInterviewAnswer(question: string, answer: string, careerPath: string): Promise<{
  score: number;
  strengths: string[];
  improvements: string[];
  alternativeResponse: string;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are an interview coach evaluating a candidate's answer. Provide constructive feedback with a score (1-10), strengths, areas for improvement, and a suggested alternative response. Respond with JSON in this format: { 'score': number, 'strengths': [array of strengths], 'improvements': [array of improvements], 'alternativeResponse': string }",
        },
        {
          role: "user",
          content: `Career Path: ${careerPath}\nQuestion: ${question}\nAnswer: ${answer}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Interview evaluation error:", error);
    throw new Error("Failed to evaluate interview answer");
  }
}

// Analyze skill gaps between user's current skills and a target career path
export async function analyzeSkillGaps(userSkills: string[], careerPathSkills: Record<string, number>): Promise<{
  matchPercentage: number;
  skillsMatch: Record<string, number>;
  missingSkills: string[];
  recommendedLearning: Array<{ skill: string; importance: string; resources?: string[] }>;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "You are a career development advisor. Analyze the gaps between the user's skills and the requirements for a career path. Provide a detailed report. Respond with JSON in this format: { 'matchPercentage': number, 'skillsMatch': { skill: percentage }, 'missingSkills': [array of missing skills], 'recommendedLearning': [{ 'skill': string, 'importance': string, 'resources': [optional array of learning resources] }] }",
        },
        {
          role: "user",
          content: JSON.stringify({
            userSkills,
            careerPathSkills
          }),
        },
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error("Skill gap analysis error:", error);
    throw new Error("Failed to analyze skill gaps");
  }
}
