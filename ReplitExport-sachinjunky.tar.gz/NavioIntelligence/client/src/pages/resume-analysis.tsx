import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  AlertTriangle,
  CheckCircle2,
  Upload,
  Download,
  Calendar,
  Loader2,
  Sparkles
} from "lucide-react";
import ResumeUploader from "@/components/resume-uploader";

export default function ResumeAnalysis() {
  const [activeResume, setActiveResume] = useState<number | null>(null);

  // Fetch all resumes
  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ['/api/resume/list'],
    queryFn: undefined, // Use the default fetcher
  });

  // Find the selected resume or use the first one
  const selectedResume = activeResume 
    ? resumes?.find(resume => resume.id === activeResume) 
    : resumes?.[0];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      
      <div className="flex flex-1">
        <Sidebar className="hidden md:block" />
        
        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Resume Analysis</h1>
                <p className="text-sm text-slate-500 mt-1">
                  Upload your resume for AI-powered feedback and improvement suggestions
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <FileText className="h-5 w-5 mr-2 text-primary-500" />
                      My Resumes
                    </CardTitle>
                    <CardDescription>
                      Upload and manage your resumes
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {resumesLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="h-6 w-6 animate-spin text-primary-500" />
                      </div>
                    ) : resumes && resumes.length > 0 ? (
                      <div className="space-y-2">
                        {resumes.map((resume) => (
                          <Button
                            key={resume.id}
                            variant={activeResume === resume.id ? "default" : "outline"}
                            className="w-full justify-start"
                            onClick={() => setActiveResume(resume.id)}
                          >
                            <FileText className="h-4 w-4 mr-2" />
                            <div className="flex flex-col items-start text-left">
                              <span className="text-sm font-medium truncate max-w-[180px]">
                                {resume.filename}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {new Date(resume.uploadedAt).toLocaleDateString()}
                              </span>
                            </div>
                          </Button>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 text-muted-foreground">
                        No resumes uploaded yet
                      </div>
                    )}
                    
                    <div className="pt-4">
                      <Button variant="outline" className="w-full">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload New Resume
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="mt-6">
                  <ResumeUploader />
                </div>
              </div>
              
              <div className="lg:col-span-2">
                {selectedResume ? (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle>{selectedResume.filename}</CardTitle>
                          <CardDescription className="flex items-center mt-1">
                            <Calendar className="h-4 w-4 mr-1" />
                            Uploaded on {new Date(selectedResume.uploadedAt).toLocaleDateString()}
                          </CardDescription>
                        </div>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <Tabs defaultValue="analysis">
                        <TabsList className="mb-4">
                          <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
                          <TabsTrigger value="preview">Resume Preview</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="analysis">
                          {selectedResume.analysis ? (
                            <div className="space-y-6">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Card>
                                  <CardHeader className="pb-2">
                                    <CardTitle className="text-base flex items-center text-amber-600">
                                      <AlertTriangle className="h-4 w-4 mr-2" />
                                      Areas for Improvement
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <ul className="space-y-2">
                                      {selectedResume.analysis.improvementAreas.map((area, index) => (
                                        <li key={index} className="flex items-start gap-2 text-sm">
                                          <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
                                          <span>{area}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardHeader className="pb-2">
                                    <CardTitle className="text-base flex items-center text-green-600">
                                      <CheckCircle2 className="h-4 w-4 mr-2" />
                                      Strengths
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <ul className="space-y-2">
                                      {selectedResume.analysis.strengths.map((strength, index) => (
                                        <li key={index} className="flex items-start gap-2 text-sm">
                                          <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                                          <span>{strength}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </CardContent>
                                </Card>
                              </div>
                              
                              <Card>
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-base flex items-center text-blue-600">
                                    <Sparkles className="h-4 w-4 mr-2" />
                                    Skills Identified
                                  </CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <div className="flex flex-wrap gap-2">
                                    {selectedResume.analysis.skillsIdentified.map((skill, index) => (
                                      <Badge key={index} variant="secondary" className="bg-blue-50 text-blue-700">
                                        {skill}
                                      </Badge>
                                    ))}
                                  </div>
                                </CardContent>
                              </Card>
                              
                              <Card>
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-base">AI Recommendations</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <div className="prose prose-slate max-w-none">
                                    <p>Based on the analysis, consider making the following improvements to your resume:</p>
                                    <ul>
                                      {selectedResume.analysis.improvementAreas.map((area, index) => (
                                        <li key={index}>{area}</li>
                                      ))}
                                    </ul>
                                    <p>Your resume effectively showcases these strengths:</p>
                                    <ul>
                                      {selectedResume.analysis.strengths.map((strength, index) => (
                                        <li key={index}>{strength}</li>
                                      ))}
                                    </ul>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center justify-center py-12 text-center">
                              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                              <h3 className="text-lg font-medium">Analyzing your resume...</h3>
                              <p className="text-muted-foreground mt-2 max-w-md">
                                Our AI is processing your resume and will provide feedback shortly.
                              </p>
                            </div>
                          )}
                        </TabsContent>
                        
                        <TabsContent value="preview">
                          <Card>
                            <CardContent className="p-6">
                              <div className="flex items-center justify-center min-h-[400px] bg-slate-50 border border-dashed rounded-lg">
                                <div className="text-center">
                                  <FileText className="h-12 w-12 text-slate-300 mb-4 mx-auto" />
                                  <h3 className="text-slate-800 font-medium">Resume Preview</h3>
                                  <p className="text-slate-500 mt-1 max-w-md">
                                    Preview functionality will be available in the next update.
                                  </p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                    
                    <CardFooter className="flex justify-between">
                      <Button variant="outline">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Revised Version
                      </Button>
                      <Button>
                        <Sparkles className="h-4 w-4 mr-2" />
                        Get AI Suggestions
                      </Button>
                    </CardFooter>
                  </Card>
                ) : (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                      <div className="rounded-full bg-slate-100 p-4 mb-4">
                        <FileText className="h-8 w-8 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-medium text-slate-900">No Resume Selected</h3>
                      <p className="text-sm text-slate-500 mt-2 max-w-md">
                        Upload your resume to get AI-powered feedback and improvement suggestions.
                      </p>
                      <div className="mt-6">
                        <ResumeUploader />
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
