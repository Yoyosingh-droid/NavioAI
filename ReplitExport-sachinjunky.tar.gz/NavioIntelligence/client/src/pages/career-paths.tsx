import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CareerMatchCard from "@/components/career-match-card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Loader2, Search, Filter, SlidersHorizontal, Check, X } from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

export default function CareerPaths() {
  const [searchTerm, setSearchTerm] = useState("");
  const [pandumpsFilter, setPandumpsFilter] = useState([0, 8]);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"all" | "saved">("all");

  // Fetch career matches
  const { data: careerMatches, isLoading } = useQuery({
    queryKey: ['/api/career-matches'],
    queryFn: undefined, // Use the default fetcher
  });

  // Filter career matches
  const filteredMatches = careerMatches?.filter((match) => {
    // Filter by search term
    const matchesSearch = searchTerm === "" || 
      match.careerPath.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      match.careerPath.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by Pandumps score
    const matchesPandumps = 
      match.careerPath.pandumpsScore.current >= pandumpsFilter[0] && 
      match.careerPath.pandumpsScore.current <= pandumpsFilter[1];
    
    // Filter by active filters
    const matchesFilters = activeFilters.length === 0 || 
      activeFilters.some(filter => {
        if (filter === "high-salary") {
          const minSalary = parseInt(match.careerPath.avgSalary.split("-")[0].replace(/\D/g, ""));
          return minSalary >= 90000;
        }
        if (filter === "growing") {
          const growth = parseFloat(match.careerPath.yoyGrowth.replace("+", "").replace("%", ""));
          return growth >= 8.0;
        }
        if (filter === "high-demand") {
          const hiringTrend = parseFloat(match.careerPath.hiringTrend.replace("+", "").replace("%", ""));
          return hiringTrend >= 10;
        }
        return false;
      });
    
    // Filter by saved status if on saved tab
    const matchesSaved = activeTab === "all" || (activeTab === "saved" && match.isSaved);
    
    return matchesSearch && matchesPandumps && matchesFilters && matchesSaved;
  });

  const savedMatches = careerMatches?.filter(match => match.isSaved) || [];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      
      <div className="flex flex-1">
        <Sidebar className="hidden md:block" />
        
        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Career Paths</h1>
                <p className="text-sm text-slate-500 mt-1">
                  Explore career paths that match your skills and preferences
                </p>
              </div>
            </div>
            
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="flex flex-col space-y-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
                    <Input
                      placeholder="Search career paths..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Pandumps Score</label>
                        <span className="text-sm text-slate-500">{pandumpsFilter[0]} - {pandumpsFilter[1]}</span>
                      </div>
                      <Slider
                        defaultValue={[0, 8]}
                        max={8}
                        step={0.5}
                        value={pandumpsFilter}
                        onValueChange={setPandumpsFilter}
                      />
                    </div>
                    
                    <div className="flex space-x-2">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="outline" size="sm" className="flex items-center">
                            <Filter className="h-4 w-4 mr-2" />
                            Filters
                            {activeFilters.length > 0 && (
                              <Badge className="ml-2 bg-primary text-white" variant="secondary">
                                {activeFilters.length}
                              </Badge>
                            )}
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56">
                          <DropdownMenuLabel>Filter By</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuCheckboxItem
                            checked={activeFilters.includes("high-salary")}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setActiveFilters([...activeFilters, "high-salary"]);
                              } else {
                                setActiveFilters(activeFilters.filter(f => f !== "high-salary"));
                              }
                            }}
                          >
                            High Salary ($90k+)
                          </DropdownMenuCheckboxItem>
                          <DropdownMenuCheckboxItem
                            checked={activeFilters.includes("growing")}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setActiveFilters([...activeFilters, "growing"]);
                              } else {
                                setActiveFilters(activeFilters.filter(f => f !== "growing"));
                              }
                            }}
                          >
                            Fast Growing (8%+ YoY)
                          </DropdownMenuCheckboxItem>
                          <DropdownMenuCheckboxItem
                            checked={activeFilters.includes("high-demand")}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setActiveFilters([...activeFilters, "high-demand"]);
                              } else {
                                setActiveFilters(activeFilters.filter(f => f !== "high-demand"));
                              }
                            }}
                          >
                            High Demand (10%+ Hiring)
                          </DropdownMenuCheckboxItem>
                          <DropdownMenuSeparator />
                          <div className="p-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="w-full"
                              onClick={() => setActiveFilters([])}
                            >
                              <X className="h-4 w-4 mr-2" />
                              Clear Filters
                            </Button>
                          </div>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      
                      <Button variant="outline" size="sm" className="flex items-center">
                        <SlidersHorizontal className="h-4 w-4 mr-2" />
                        Sort
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Tabs defaultValue="all" value={activeTab} onValueChange={(value) => setActiveTab(value as "all" | "saved")}>
              <div className="flex items-center justify-between mb-4">
                <TabsList>
                  <TabsTrigger value="all">All Matches</TabsTrigger>
                  <TabsTrigger value="saved">
                    Saved Careers
                    {savedMatches.length > 0 && (
                      <Badge className="ml-2 bg-primary text-white" variant="secondary">
                        {savedMatches.length}
                      </Badge>
                    )}
                  </TabsTrigger>
                </TabsList>
                
                {activeFilters.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-slate-500">Active filters:</span>
                    {activeFilters.map((filter) => (
                      <Badge key={filter} variant="outline" className="flex items-center gap-1">
                        {filter === "high-salary" 
                          ? "High Salary" 
                          : filter === "growing" 
                          ? "Fast Growing" 
                          : "High Demand"}
                        <X 
                          className="h-3 w-3 cursor-pointer" 
                          onClick={() => setActiveFilters(activeFilters.filter(f => f !== filter))}
                        />
                      </Badge>
                    ))}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setActiveFilters([])}
                      className="h-8 px-2 text-xs"
                    >
                      Clear all
                    </Button>
                  </div>
                )}
              </div>
              
              <TabsContent value="all">
                {isLoading ? (
                  <div className="flex justify-center items-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredMatches && filteredMatches.length > 0 ? (
                  <div className="space-y-6">
                    {filteredMatches.map((match) => (
                      <CareerMatchCard key={match.id} careerMatch={match} />
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <div className="rounded-full bg-slate-100 p-3 mb-4">
                        <Search className="h-6 w-6 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-medium text-slate-900">No matches found</h3>
                      <p className="text-sm text-slate-500 mt-1 max-w-md text-center">
                        Try adjusting your filters or search terms to find more career matches.
                      </p>
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => {
                          setSearchTerm("");
                          setPandumpsFilter([0, 8]);
                          setActiveFilters([]);
                        }}
                      >
                        Reset All Filters
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
              
              <TabsContent value="saved">
                {isLoading ? (
                  <div className="flex justify-center items-center p-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredMatches && filteredMatches.length > 0 ? (
                  <div className="space-y-6">
                    {filteredMatches.map((match) => (
                      <CareerMatchCard key={match.id} careerMatch={match} />
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-12">
                      <div className="rounded-full bg-slate-100 p-3 mb-4">
                        <Check className="h-6 w-6 text-slate-400" />
                      </div>
                      <h3 className="text-lg font-medium text-slate-900">No saved careers</h3>
                      <p className="text-sm text-slate-500 mt-1 max-w-md text-center">
                        You haven't saved any career paths yet. Save careers to compare them later.
                      </p>
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => setActiveTab("all")}
                      >
                        Browse All Careers
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
