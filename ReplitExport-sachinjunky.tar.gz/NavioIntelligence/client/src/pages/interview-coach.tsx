import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  MessageSquare, 
  Calendar, 
  CheckCircle2, 
  PlayCircle,
  Clock,
  ChevronRight,
  CalendarPlus,
  Laptop,
  Building,
  User,
  Briefcase,
  Sparkles
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import InterviewSimulator from "@/components/interview-simulator";

export default function InterviewCoach() {
  const [selectedInterviewType, setSelectedInterviewType] = useState("Behavioral");
  const [selectedCareerPath, setSelectedCareerPath] = useState("UX/UI Designer");
  const [schedulingDate, setSchedulingDate] = useState<Date | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [simulationMode, setSimulationMode] = useState(false);
  const [activeSession, setActiveSession] = useState<number | null>(null);
  const { toast } = useToast();

  // Fetch career paths
  const { data: careerPaths, isLoading: pathsLoading } = useQuery({
    queryKey: ['/api/career-paths'],
    queryFn: undefined, // Use the default fetcher
  });

  // Fetch interview sessions
  const { data: sessions, isLoading: sessionsLoading } = useQuery({
    queryKey: ['/api/interview-sessions'],
    queryFn: undefined, // Use the default fetcher
  });

  // Create a new interview session
  const createSessionMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/interview-sessions", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interview-sessions'] });
      toast({
        title: "Session scheduled",
        description: "Your interview practice session has been scheduled",
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to schedule session",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSchedule = () => {
    createSessionMutation.mutate({
      interviewType: selectedInterviewType,
      careerPath: selectedCareerPath,
      scheduledAt: new Date(new Date().getTime() + 24 * 60 * 60 * 1000) // Tomorrow
    });
  };

  const startPractice = (sessionId: number) => {
    setActiveSession(sessionId);
    setSimulationMode(true);
  };

  const completedSessions = sessions?.filter(session => session.completedAt) || [];
  const upcomingSessions = sessions?.filter(session => !session.completedAt) || [];
  
  const interviewTypes = [
    { 
      name: "Behavioral", 
      icon: <MessageSquare className="h-5 w-5" />,
      color: "bg-primary-100 text-primary-600",
      description: "Practice questions about past experiences and how you handled situations."
    },
    { 
      name: "Technical", 
      icon: <Laptop className="h-5 w-5" />,
      color: "bg-secondary-100 text-secondary-600",
      description: "Practice domain-specific questions and problem-solving scenarios."
    },
    { 
      name: "Company-Specific", 
      icon: <Building className="h-5 w-5" />,
      color: "bg-orange-100 text-orange-500",
      description: "Prepare for interviews with questions tailored to specific companies."
    },
    { 
      name: "Salary Negotiation", 
      icon: <User className="h-5 w-5" />,
      color: "bg-green-100 text-green-600",
      description: "Practice discussing compensation and benefits effectively."
    }
  ];

  if (simulationMode) {
    const session = sessions?.find(s => s.id === activeSession);
    
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <Navbar />
        
        <div className="flex flex-1">
          <Sidebar className="hidden md:block" />
          
          <main className="flex-1 p-6">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center mb-6">
                <Button 
                  variant="ghost" 
                  className="mr-2" 
                  onClick={() => setSimulationMode(false)}
                >
                  <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                  Back to sessions
                </Button>
                <h1 className="text-2xl font-bold text-slate-900">Interview Practice</h1>
              </div>
              
              {session && (
                <InterviewSimulator 
                  careerPath={session.careerPath || selectedCareerPath}
                  interviewType={session.interviewType || selectedInterviewType}
                  sessionId={session.id}
                />
              )}
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      
      <div className="flex flex-1">
        <Sidebar className="hidden md:block" />
        
        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Interview Coach</h1>
                <p className="text-sm text-slate-500 mt-1">
                  Practice interviews with AI-powered feedback
                </p>
              </div>
              <div className="mt-4 md:mt-0">
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <CalendarPlus className="mr-2 h-4 w-4" />
                      Schedule New Practice
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Schedule Interview Practice</DialogTitle>
                      <DialogDescription>
                        Set up your AI-powered interview practice session.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <label htmlFor="interview-type" className="text-sm font-medium">
                          Interview Type
                        </label>
                        <Select 
                          value={selectedInterviewType} 
                          onValueChange={setSelectedInterviewType}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select interview type" />
                          </SelectTrigger>
                          <SelectContent>
                            {interviewTypes.map((type) => (
                              <SelectItem key={type.name} value={type.name}>
                                <div className="flex items-center">
                                  <div className={`flex items-center justify-center h-6 w-6 rounded-md ${type.color} mr-2`}>
                                    {type.icon}
                                  </div>
                                  {type.name}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid gap-2">
                        <label htmlFor="career-path" className="text-sm font-medium">
                          Career Path
                        </label>
                        <Select 
                          value={selectedCareerPath} 
                          onValueChange={setSelectedCareerPath}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select career path" />
                          </SelectTrigger>
                          <SelectContent>
                            {pathsLoading ? (
                              <SelectItem value="loading" disabled>
                                Loading...
                              </SelectItem>
                            ) : careerPaths?.map((path) => (
                              <SelectItem key={path.id} value={path.title}>
                                {path.title}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleSchedule} disabled={createSessionMutation.isPending}>
                        {createSessionMutation.isPending ? (
                          <>
                            <span className="animate-spin h-4 w-4 mr-2 border-2 border-b-0 border-r-0 rounded-full inline-block"></span>
                            Scheduling...
                          </>
                        ) : (
                          <>
                            <Calendar className="mr-2 h-4 w-4" />
                            Schedule
                          </>
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
            
            <Tabs defaultValue="upcoming">
              <TabsList className="mb-4">
                <TabsTrigger value="upcoming">Upcoming Sessions</TabsTrigger>
                <TabsTrigger value="completed">Completed Sessions</TabsTrigger>
                <TabsTrigger value="practice">Practice Now</TabsTrigger>
              </TabsList>
              
              <TabsContent value="upcoming">
                <div className="grid grid-cols-1 gap-4">
                  {sessionsLoading ? (
                    <Card>
                      <CardContent className="flex justify-center items-center p-6">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      </CardContent>
                    </Card>
                  ) : upcomingSessions.length > 0 ? (
                    upcomingSessions.map((session) => (
                      <Card key={session.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="flex flex-col sm:flex-row sm:items-center p-6 border-b">
                            <div className="flex-1">
                              <div className="flex items-center">
                                <div className={`flex items-center justify-center h-10 w-10 rounded-md ${
                                  session.interviewType === "Behavioral" ? "bg-primary-100 text-primary-600" :
                                  session.interviewType === "Technical" ? "bg-secondary-100 text-secondary-600" :
                                  session.interviewType === "Company-Specific" ? "bg-orange-100 text-orange-500" :
                                  "bg-green-100 text-green-600"
                                } mr-4`}>
                                  {session.interviewType === "Behavioral" ? <MessageSquare className="h-5 w-5" /> :
                                   session.interviewType === "Technical" ? <Laptop className="h-5 w-5" /> :
                                   session.interviewType === "Company-Specific" ? <Building className="h-5 w-5" /> :
                                   <User className="h-5 w-5" />}
                                </div>
                                <div>
                                  <h3 className="text-md font-medium text-slate-900">{session.interviewType} Interview</h3>
                                  <p className="text-sm text-slate-500">
                                    {session.careerPath} role
                                  </p>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center mt-4 sm:mt-0">
                              <Badge variant="outline" className="mr-4 bg-blue-50 text-blue-700 flex items-center">
                                <Calendar className="mr-1 h-3 w-3" />
                                {session.scheduledAt 
                                  ? new Date(session.scheduledAt).toLocaleDateString() 
                                  : "Not scheduled"}
                              </Badge>
                              <Button
                                size="sm"
                                onClick={() => startPractice(session.id)}
                              >
                                <PlayCircle className="mr-2 h-4 w-4" />
                                Start
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <Card>
                      <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                        <Calendar className="h-12 w-12 text-slate-300 mb-4" />
                        <h3 className="text-lg font-medium text-slate-900">No upcoming sessions</h3>
                        <p className="text-sm text-slate-500 mt-1 max-w-md">
                          Schedule an interview practice session to prepare for your next interview.
                        </p>
                        <Button className="mt-4" onClick={() => setDialogOpen(true)}>
                          <CalendarPlus className="mr-2 h-4 w-4" />
                          Schedule New Practice
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="completed">
                <div className="grid grid-cols-1 gap-4">
                  {sessionsLoading ? (
                    <Card>
                      <CardContent className="flex justify-center items-center p-6">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      </CardContent>
                    </Card>
                  ) : completedSessions.length > 0 ? (
                    completedSessions.map((session) => (
                      <Card key={session.id}>
                        <CardContent className="p-6">
                          <div className="flex flex-col sm:flex-row sm:items-center">
                            <div className="flex-1">
                              <div className="flex items-center">
                                <div className={`flex items-center justify-center h-10 w-10 rounded-md ${
                                  session.interviewType === "Behavioral" ? "bg-primary-100 text-primary-600" :
                                  session.interviewType === "Technical" ? "bg-secondary-100 text-secondary-600" :
                                  session.interviewType === "Company-Specific" ? "bg-orange-100 text-orange-500" :
                                  "bg-green-100 text-green-600"
                                } mr-4`}>
                                  {session.interviewType === "Behavioral" ? <MessageSquare className="h-5 w-5" /> :
                                   session.interviewType === "Technical" ? <Laptop className="h-5 w-5" /> :
                                   session.interviewType === "Company-Specific" ? <Building className="h-5 w-5" /> :
                                   <User className="h-5 w-5" />}
                                </div>
                                <div>
                                  <h3 className="text-md font-medium text-slate-900">{session.interviewType} Interview</h3>
                                  <div className="flex items-center text-sm text-slate-500">
                                    <span>{session.careerPath} role</span>
                                    <span className="mx-2">•</span>
                                    <span className="flex items-center">
                                      <Clock className="h-3 w-3 mr-1" />
                                      {session.completedAt && new Date(session.completedAt).toLocaleDateString()}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="mt-4 sm:mt-0 flex flex-col sm:items-end">
                              {session.feedback && (
                                <div className="flex flex-col space-y-2 mb-2">
                                  <Badge className="bg-green-100 text-green-800">
                                    Score: {session.feedback.averageScore}/10
                                  </Badge>
                                  <div className="text-xs text-slate-500">
                                    Completed {session.feedback.questionsAnswered} of {session.feedback.totalQuestions} questions
                                  </div>
                                </div>
                              )}
                              <Button variant="outline" size="sm">
                                <CheckCircle2 className="mr-2 h-4 w-4" />
                                View Results
                              </Button>
                            </div>
                          </div>
                          
                          {session.feedback && (
                            <div className="mt-4">
                              <div className="text-sm text-slate-600 mt-2">
                                Progress
                              </div>
                              <Progress
                                value={(session.feedback.questionsAnswered / session.feedback.totalQuestions) * 100}
                                className="h-2 mt-1"
                              />
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <Card>
                      <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                        <CheckCircle2 className="h-12 w-12 text-slate-300 mb-4" />
                        <h3 className="text-lg font-medium text-slate-900">No completed sessions</h3>
                        <p className="text-sm text-slate-500 mt-1 max-w-md">
                          Complete an interview practice session to see your results here.
                        </p>
                        <Button className="mt-4" onClick={() => setDialogOpen(true)}>
                          <CalendarPlus className="mr-2 h-4 w-4" />
                          Schedule New Practice
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="practice">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {interviewTypes.map((type) => (
                    <Card 
                      key={type.name} 
                      className="cursor-pointer hover:border-primary transition-all duration-200"
                      onClick={() => {
                        setSelectedInterviewType(type.name);
                        createSessionMutation.mutate({
                          interviewType: type.name,
                          careerPath: selectedCareerPath || "General"
                        });
                      }}
                    >
                      <CardContent className="p-6">
                        <div className="flex flex-col items-center text-center">
                          <div className={`flex items-center justify-center h-12 w-12 rounded-md ${type.color} mb-4`}>
                            {type.icon}
                          </div>
                          <h3 className="text-md font-medium text-slate-900 mb-2">{type.name} Interview</h3>
                          <p className="text-sm text-slate-500 mb-4">
                            {type.description}
                          </p>
                          <Button variant="outline" size="sm" className="w-full">
                            <PlayCircle className="mr-2 h-4 w-4" />
                            Start Practice
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <Card className="mt-8">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Sparkles className="h-5 w-5 mr-2 text-primary-500" />
                      Interview Tips
                    </CardTitle>
                    <CardDescription>
                      Key strategies to excel in your interviews
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <div className="flex items-center mb-2">
                          <MessageSquare className="h-5 w-5 text-primary-600 mr-2" />
                          <h3 className="font-medium">For Behavioral Interviews</h3>
                        </div>
                        <ul className="text-sm space-y-2">
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-primary-600 mt-0.5 mr-1 shrink-0" />
                            Use the STAR method (Situation, Task, Action, Result)
                          </li>
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-primary-600 mt-0.5 mr-1 shrink-0" />
                            Prepare specific examples from your experience
                          </li>
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-primary-600 mt-0.5 mr-1 shrink-0" />
                            Highlight problem-solving and initiative
                          </li>
                        </ul>
                      </div>
                      
                      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <div className="flex items-center mb-2">
                          <Laptop className="h-5 w-5 text-secondary-600 mr-2" />
                          <h3 className="font-medium">For Technical Interviews</h3>
                        </div>
                        <ul className="text-sm space-y-2">
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-secondary-600 mt-0.5 mr-1 shrink-0" />
                            Think out loud while solving problems
                          </li>
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-secondary-600 mt-0.5 mr-1 shrink-0" />
                            Ask clarifying questions before diving in
                          </li>
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-secondary-600 mt-0.5 mr-1 shrink-0" />
                            Explain your approach and reasoning
                          </li>
                        </ul>
                      </div>
                      
                      <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                        <div className="flex items-center mb-2">
                          <Briefcase className="h-5 w-5 text-orange-600 mr-2" />
                          <h3 className="font-medium">General Preparation</h3>
                        </div>
                        <ul className="text-sm space-y-2">
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-orange-600 mt-0.5 mr-1 shrink-0" />
                            Research the company thoroughly
                          </li>
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-orange-600 mt-0.5 mr-1 shrink-0" />
                            Practice with our AI simulator regularly
                          </li>
                          <li className="flex items-start">
                            <ChevronRight className="h-4 w-4 text-orange-600 mt-0.5 mr-1 shrink-0" />
                            Prepare thoughtful questions to ask the interviewer
                          </li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
