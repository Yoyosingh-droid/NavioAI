import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import { 
  User, 
  Mail, 
  Calendar, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Target, 
  MapPin,
  PlusCircle,
  Trash2, 
  Sparkles,
  Save,
  Loader2 
} from "lucide-react";

// Form schema for user info
const userInfoSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  location: z.string().optional(),
  bio: z.string().optional(),
});

// Form schema for education
const educationSchema = z.object({
  items: z.array(
    z.object({
      institution: z.string().min(1, { message: "Institution is required" }),
      degree: z.string().min(1, { message: "Degree is required" }),
      field: z.string().min(1, { message: "Field of study is required" }),
      startYear: z.string().min(1, { message: "Start year is required" }),
      endYear: z.string().min(1, { message: "End year is required" }),
    })
  )
});

// Form schema for experience
const experienceSchema = z.object({
  items: z.array(
    z.object({
      company: z.string().min(1, { message: "Company is required" }),
      position: z.string().min(1, { message: "Position is required" }),
      description: z.string().optional(),
      startDate: z.string().min(1, { message: "Start date is required" }),
      endDate: z.string().optional(),
      current: z.boolean().default(false),
    })
  )
});

// Form schema for skills
const skillsSchema = z.object({
  items: z.array(
    z.object({
      name: z.string().min(1, { message: "Skill name is required" }),
      level: z.enum(["Beginner", "Intermediate", "Advanced", "Expert"]),
    })
  )
});

// Form schema for goals
const goalsSchema = z.object({
  shortTerm: z.string().optional(),
  longTerm: z.string().optional(),
  industries: z.array(z.string()).optional(),
});

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState("general");

  // Fetch profile data
  const { data: profileData, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/profile'],
    queryFn: undefined, // Use the default fetcher
  });

  // Initialize the forms
  const userInfoForm = useForm<z.infer<typeof userInfoSchema>>({
    resolver: zodResolver(userInfoSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      location: profileData?.location || "",
      bio: profileData?.bio || "",
    },
  });

  // Education form with default values
  const educationForm = useForm<z.infer<typeof educationSchema>>({
    resolver: zodResolver(educationSchema),
    defaultValues: {
      items: profileData?.education?.items || [],
    },
  });
  
  // Experience form with default values
  const experienceForm = useForm<z.infer<typeof experienceSchema>>({
    resolver: zodResolver(experienceSchema),
    defaultValues: {
      items: profileData?.experience?.items || [],
    },
  });
  
  // Skills form with default values
  const skillsForm = useForm<z.infer<typeof skillsSchema>>({
    resolver: zodResolver(skillsSchema),
    defaultValues: {
      items: profileData?.skills?.items || [],
    },
  });
  
  // Goals form with default values
  const goalsForm = useForm<z.infer<typeof goalsSchema>>({
    resolver: zodResolver(goalsSchema),
    defaultValues: {
      shortTerm: profileData?.goals?.shortTerm || "",
      longTerm: profileData?.goals?.longTerm || "",
      industries: profileData?.goals?.industries || [],
    },
  });

  // Update forms when profile data is loaded
  useEffect(() => {
    if (profileData) {
      userInfoForm.reset({
        name: user?.name || "",
        email: user?.email || "",
        location: profileData.location || "",
        bio: profileData.bio || "",
      });
      
      educationForm.reset({
        items: profileData.education?.items || [],
      });
      
      experienceForm.reset({
        items: profileData.experience?.items || [],
      });
      
      skillsForm.reset({
        items: profileData.skills?.items || [],
      });
      
      goalsForm.reset({
        shortTerm: profileData.goals?.shortTerm || "",
        longTerm: profileData.goals?.longTerm || "",
        industries: profileData.goals?.industries || [],
      });
    }
  }, [profileData, user]);

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/profile", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submissions
  const onUserInfoSubmit = (values: z.infer<typeof userInfoSchema>) => {
    updateProfileMutation.mutate({
      ...profileData,
      location: values.location,
      bio: values.bio,
    });
  };
  
  const onEducationSubmit = (values: z.infer<typeof educationSchema>) => {
    updateProfileMutation.mutate({
      ...profileData,
      education: values,
    });
  };
  
  const onExperienceSubmit = (values: z.infer<typeof experienceSchema>) => {
    updateProfileMutation.mutate({
      ...profileData,
      experience: values,
    });
  };
  
  const onSkillsSubmit = (values: z.infer<typeof skillsSchema>) => {
    updateProfileMutation.mutate({
      ...profileData,
      skills: values,
    });
  };
  
  const onGoalsSubmit = (values: z.infer<typeof goalsSchema>) => {
    updateProfileMutation.mutate({
      ...profileData,
      goals: values,
    });
  };

  // Add education item
  const addEducationItem = () => {
    const currentItems = educationForm.getValues().items || [];
    educationForm.setValue("items", [
      ...currentItems,
      { institution: "", degree: "", field: "", startYear: "", endYear: "" }
    ]);
  };
  
  // Remove education item
  const removeEducationItem = (index: number) => {
    const currentItems = educationForm.getValues().items || [];
    educationForm.setValue("items", currentItems.filter((_, i) => i !== index));
  };
  
  // Add experience item
  const addExperienceItem = () => {
    const currentItems = experienceForm.getValues().items || [];
    experienceForm.setValue("items", [
      ...currentItems,
      { company: "", position: "", description: "", startDate: "", endDate: "", current: false }
    ]);
  };
  
  // Remove experience item
  const removeExperienceItem = (index: number) => {
    const currentItems = experienceForm.getValues().items || [];
    experienceForm.setValue("items", currentItems.filter((_, i) => i !== index));
  };
  
  // Add skill item
  const addSkillItem = () => {
    const currentItems = skillsForm.getValues().items || [];
    skillsForm.setValue("items", [
      ...currentItems,
      { name: "", level: "Beginner" }
    ]);
  };
  
  // Remove skill item
  const removeSkillItem = (index: number) => {
    const currentItems = skillsForm.getValues().items || [];
    skillsForm.setValue("items", currentItems.filter((_, i) => i !== index));
  };

  // Get initials for avatar
  const getInitials = () => {
    if (user?.name) {
      return user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase();
    }
    return user?.username?.substring(0, 2).toUpperCase() || "U";
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      
      <div className="flex flex-1">
        <Sidebar className="hidden md:block" />
        
        <main className="flex-1 p-6">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Profile</h1>
                <p className="text-sm text-slate-500 mt-1">
                  Manage your account information and career details
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-6">
              {/* User Card */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center gap-6">
                    <Avatar className="h-24 w-24">
                      <AvatarFallback className="text-2xl">{getInitials()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold">{user?.name || user?.username}</h2>
                      <p className="text-slate-500 flex items-center mt-1">
                        <Mail className="h-4 w-4 mr-1" />
                        {user?.email}
                      </p>
                      {profileData?.location && (
                        <p className="text-slate-500 flex items-center mt-1">
                          <MapPin className="h-4 w-4 mr-1" />
                          {profileData.location}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-2 mt-3">
                        {profileData?.skills?.items?.slice(0, 5).map((skill, index) => (
                          <Badge key={index} variant="secondary">
                            {skill.name}
                          </Badge>
                        ))}
                        {profileData?.skills?.items && profileData.skills.items.length > 5 && (
                          <Badge variant="outline">+{profileData.skills.items.length - 5} more</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Profile Sections */}
              <Tabs value={currentTab} onValueChange={setCurrentTab}>
                <TabsList className="mb-6">
                  <TabsTrigger value="general">General</TabsTrigger>
                  <TabsTrigger value="education">Education</TabsTrigger>
                  <TabsTrigger value="experience">Experience</TabsTrigger>
                  <TabsTrigger value="skills">Skills</TabsTrigger>
                  <TabsTrigger value="goals">Career Goals</TabsTrigger>
                </TabsList>
                
                {/* General Tab */}
                <TabsContent value="general">
                  <Card>
                    <CardHeader>
                      <CardTitle>General Information</CardTitle>
                      <CardDescription>
                        Update your basic personal information
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...userInfoForm}>
                        <form onSubmit={userInfoForm.handleSubmit(onUserInfoSubmit)} className="space-y-6">
                          <FormField
                            control={userInfoForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="Enter your full name" 
                                    {...field} 
                                    disabled
                                  />
                                </FormControl>
                                <FormDescription>
                                  This is your display name. You can change it by updating your account settings.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={userInfoForm.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="Enter your email" 
                                    {...field} 
                                    disabled
                                  />
                                </FormControl>
                                <FormDescription>
                                  Your email address is tied to your account and cannot be changed here.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={userInfoForm.control}
                            name="location"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Location</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="City, Country" 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  Your current location helps with job recommendations.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={userInfoForm.control}
                            name="bio"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Bio</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Tell us a little about yourself" 
                                    className="min-h-[120px]"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  A brief description about yourself and your professional background.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Changes
                              </>
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                {/* Education Tab */}
                <TabsContent value="education">
                  <Card>
                    <CardHeader>
                      <CardTitle>Education</CardTitle>
                      <CardDescription>
                        Add your educational background and qualifications
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...educationForm}>
                        <form onSubmit={educationForm.handleSubmit(onEducationSubmit)} className="space-y-6">
                          {educationForm.watch("items")?.map((_, index) => (
                            <div key={index} className="p-4 border rounded-md space-y-4">
                              <div className="flex justify-between items-center">
                                <h3 className="font-medium flex items-center">
                                  <GraduationCap className="h-4 w-4 mr-2" />
                                  Education #{index + 1}
                                </h3>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeEducationItem(index)}
                                >
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <FormField
                                  control={educationForm.control}
                                  name={`items.${index}.institution`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Institution</FormLabel>
                                      <FormControl>
                                        <Input placeholder="University name" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={educationForm.control}
                                  name={`items.${index}.degree`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Degree</FormLabel>
                                      <FormControl>
                                        <Input placeholder="Bachelor's, Master's, etc." {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <FormField
                                control={educationForm.control}
                                name={`items.${index}.field`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Field of Study</FormLabel>
                                    <FormControl>
                                      <Input placeholder="Computer Science, Business, etc." {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <FormField
                                  control={educationForm.control}
                                  name={`items.${index}.startYear`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Start Year</FormLabel>
                                      <FormControl>
                                        <Input type="text" placeholder="2018" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={educationForm.control}
                                  name={`items.${index}.endYear`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>End Year (or Expected)</FormLabel>
                                      <FormControl>
                                        <Input type="text" placeholder="2022" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                            </div>
                          ))}
                          
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={addEducationItem}
                            className="w-full"
                          >
                            <PlusCircle className="h-4 w-4 mr-2" />
                            Add Education
                          </Button>
                          
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Education
                              </>
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                {/* Experience Tab */}
                <TabsContent value="experience">
                  <Card>
                    <CardHeader>
                      <CardTitle>Work Experience</CardTitle>
                      <CardDescription>
                        Add your professional work experience
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...experienceForm}>
                        <form onSubmit={experienceForm.handleSubmit(onExperienceSubmit)} className="space-y-6">
                          {experienceForm.watch("items")?.map((_, index) => (
                            <div key={index} className="p-4 border rounded-md space-y-4">
                              <div className="flex justify-between items-center">
                                <h3 className="font-medium flex items-center">
                                  <Briefcase className="h-4 w-4 mr-2" />
                                  Experience #{index + 1}
                                </h3>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeExperienceItem(index)}
                                >
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <FormField
                                  control={experienceForm.control}
                                  name={`items.${index}.company`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Company</FormLabel>
                                      <FormControl>
                                        <Input placeholder="Company name" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={experienceForm.control}
                                  name={`items.${index}.position`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Position</FormLabel>
                                      <FormControl>
                                        <Input placeholder="Job title" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <FormField
                                control={experienceForm.control}
                                name={`items.${index}.description`}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                      <Textarea 
                                        placeholder="Describe your responsibilities and achievements" 
                                        className="min-h-[80px]"
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <FormField
                                  control={experienceForm.control}
                                  name={`items.${index}.startDate`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Start Date</FormLabel>
                                      <FormControl>
                                        <Input type="text" placeholder="Jan 2020" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={experienceForm.control}
                                  name={`items.${index}.endDate`}
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>End Date</FormLabel>
                                      <FormControl>
                                        <Input 
                                          type="text" 
                                          placeholder="Dec 2022 or Present" 
                                          {...field} 
                                          disabled={experienceForm.watch(`items.${index}.current`)}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                            </div>
                          ))}
                          
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={addExperienceItem}
                            className="w-full"
                          >
                            <PlusCircle className="h-4 w-4 mr-2" />
                            Add Experience
                          </Button>
                          
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Experience
                              </>
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                {/* Skills Tab */}
                <TabsContent value="skills">
                  <Card>
                    <CardHeader>
                      <CardTitle>Skills</CardTitle>
                      <CardDescription>
                        Add your professional and technical skills
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...skillsForm}>
                        <form onSubmit={skillsForm.handleSubmit(onSkillsSubmit)} className="space-y-6">
                          {skillsForm.watch("items")?.map((_, index) => (
                            <div key={index} className="flex items-center space-x-4">
                              <FormField
                                control={skillsForm.control}
                                name={`items.${index}.name`}
                                render={({ field }) => (
                                  <FormItem className="flex-1">
                                    <FormControl>
                                      <Input placeholder="Skill name" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={skillsForm.control}
                                name={`items.${index}.level`}
                                render={({ field }) => (
                                  <FormItem className="w-36">
                                    <Select
                                      value={field.value}
                                      onValueChange={field.onChange}
                                    >
                                      <SelectTrigger>
                                        <SelectValue placeholder="Level" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="Beginner">Beginner</SelectItem>
                                        <SelectItem value="Intermediate">Intermediate</SelectItem>
                                        <SelectItem value="Advanced">Advanced</SelectItem>
                                        <SelectItem value="Expert">Expert</SelectItem>
                                      </SelectContent>
                                    </Select>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => removeSkillItem(index)}
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          ))}
                          
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={addSkillItem}
                            className="w-full"
                          >
                            <PlusCircle className="h-4 w-4 mr-2" />
                            Add Skill
                          </Button>
                          
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Skills
                              </>
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                {/* Goals Tab */}
                <TabsContent value="goals">
                  <Card>
                    <CardHeader>
                      <CardTitle>Career Goals</CardTitle>
                      <CardDescription>
                        Define your professional aspirations and career objectives
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...goalsForm}>
                        <form onSubmit={goalsForm.handleSubmit(onGoalsSubmit)} className="space-y-6">
                          <FormField
                            control={goalsForm.control}
                            name="shortTerm"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Short-Term Goals (1-2 years)</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="What do you want to achieve in the next 1-2 years?" 
                                    className="min-h-[100px]"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  Specific objectives you want to accomplish in the near future.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={goalsForm.control}
                            name="longTerm"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Long-Term Goals (3-5 years)</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Where do you see yourself in 3-5 years?" 
                                    className="min-h-[100px]"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormDescription>
                                  Your broader career aspirations and where you want to be in the future.
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <Button 
                            type="submit" 
                            disabled={updateProfileMutation.isPending}
                          >
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Goals
                              </>
                            )}
                          </Button>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}


