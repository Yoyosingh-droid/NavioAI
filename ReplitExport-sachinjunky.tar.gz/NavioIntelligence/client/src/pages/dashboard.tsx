import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Navbar from "@/components/layout/navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import ProfileProgress from "@/components/profile-progress";
import CareerMatchCard from "@/components/career-match-card";
import { UserCog, FileText, MessageSquare, CalendarCheck, BookOpen, Briefcase, GraduationCap, BrainCircuit, AlertTriangle, Check, Upload, AlertCircle, CheckCircle, Star, StarHalf, Monitor, Users, Layers } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Link, useLocation } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  const [isGeneratingMatches, setIsGeneratingMatches] = useState(false);

  // Fetch profile data
  const { data: profileData, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/profile'],
    queryFn: undefined, // Use the default fetcher
  });

  // Check if personality quiz needs to be taken
  const needsPersonalityQuiz = !profileLoading && profileData && !profileData.personalityResult;

  // Fetch career matches
  const { 
    data: careerMatches, 
    isLoading: matchesLoading,
    refetch: refetchMatches
  } = useQuery({
    queryKey: ['/api/career-matches'],
    queryFn: undefined, // Use the default fetcher
  });

  // Fetch resume list
  const { data: resumes, isLoading: resumesLoading } = useQuery({
    queryKey: ['/api/resume/list'],
    queryFn: undefined, // Use the default fetcher
  });

  // Fetch interview sessions
  const { data: interviewSessions, isLoading: sessionsLoading } = useQuery({
    queryKey: ['/api/interview-sessions'],
    queryFn: undefined, // Use the default fetcher
  });

  // Generate career matches if none exist
  const generateCareerMatches = async () => {
    try {
      setIsGeneratingMatches(true);
      await apiRequest("GET", "/api/suggest-careers");
      refetchMatches();
    } catch (error) {
      console.error("Error generating career matches:", error);
    } finally {
      setIsGeneratingMatches(false);
    }
  };

  // If no matches are found, suggest generating them
  useEffect(() => {
    if (!matchesLoading && careerMatches && careerMatches.length === 0 && !needsPersonalityQuiz) {
      generateCareerMatches();
    }
  }, [matchesLoading, careerMatches, needsPersonalityQuiz]);

  // Calculate progress metrics
  const profileProgress = profileData?.profileCompleted ? 100 : 
    profileData ? 
      (Object.keys(profileData).filter(key => 
        profileData[key] && key !== 'id' && key !== 'userId' && key !== 'profileCompleted'
      ).length / 5) * 100 : 0;

  const resumeStatus = resumes && resumes.length > 0 ? "Needs Review" : "Not Uploaded";
  const resumeProgress = resumes && resumes.length > 0 ? 65 : 0;

  const interviewProgress = interviewSessions ? 
    (interviewSessions.filter(session => session.completedAt).length / 5) * 100 : 0;

  const progressItems = [
    {
      icon: <GraduationCap className="h-5 w-5" />,
      title: "Profile Completion",
      value: Math.round(profileProgress),
      description: profileProgress < 100 ? "Complete your profile" : "Completed",
      color: "bg-primary-600"
    },
    {
      icon: <FileText className="h-5 w-5" />,
      title: "Resume Status",
      value: resumeProgress,
      description: resumeStatus,
      color: "bg-secondary-500"
    },
    {
      icon: <MessageSquare className="h-5 w-5" />,
      title: "Interview Practice",
      value: Math.round(interviewProgress),
      description: interviewSessions && interviewSessions.filter(session => session.completedAt).length > 0 
        ? `${interviewSessions.filter(session => session.completedAt).length} completed` : "Not started",
      color: "bg-green-600"
    },
    {
      icon: <BookOpen className="h-5 w-5" />,
      title: "Action Items",
      value: 75,
      description: "3 pending tasks",
      color: "bg-orange-500"
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Personality Quiz Prompt */}
        {needsPersonalityQuiz && (
          <div className="bg-primary-50 border-y border-primary-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <BrainCircuit className="h-8 w-8 text-primary-500" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-medium text-primary-800">Complete your personality assessment</h3>
                    <p className="text-sm text-primary-600">
                      Take our quick personality quiz to get personalized career recommendations
                    </p>
                  </div>
                </div>
                <div>
                  <Link href="/quiz">
                    <Button>
                      Start Quiz
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="md:flex md:items-center md:justify-between mb-8">
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold leading-7 text-slate-900 sm:text-3xl sm:truncate">
                Welcome back, {user?.name || user?.username}
              </h1>
              <p className="mt-1 text-sm text-slate-500">
                Let's continue building your career path today
              </p>
            </div>
            <div className="mt-4 flex md:mt-0 md:ml-4">
              <Link href="/interview">
                <Button>
                  <CalendarCheck className="mr-2 h-4 w-4" />
                  Schedule AI Coach
                </Button>
              </Link>
            </div>
          </div>

          {/* Progress Overview */}
          <ProfileProgress items={progressItems} />

          {/* Top Career Matches */}
          <div className="bg-white rounded-lg shadow mb-8 mt-8">
            <div className="px-6 py-5 border-b border-slate-200">
              <h2 className="text-lg font-medium text-slate-900">Your Top Career Matches</h2>
              <p className="mt-1 text-sm text-slate-500">Based on your skills, education, and personality profile</p>
            </div>
            <div className="px-6 py-5">
              {matchesLoading || isGeneratingMatches ? (
                <div className="flex justify-center items-center p-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
                  <span className="ml-3 text-slate-600">{isGeneratingMatches ? 'Generating career matches...' : 'Loading career matches...'}</span>
                </div>
              ) : careerMatches && careerMatches.length > 0 ? (
                <>
                  {careerMatches.slice(0, 2).map((match) => (
                    <CareerMatchCard key={match.id} careerMatch={match} />
                  ))}
                </>
              ) : (
                <div className="text-center py-8">
                  <UserCog className="mx-auto h-12 w-12 text-slate-400" />
                  <h3 className="mt-2 text-sm font-medium text-slate-900">No career matches</h3>
                  <p className="mt-1 text-sm text-slate-500">Complete your profile to get personalized career matches.</p>
                  <div className="mt-6">
                    <Button onClick={generateCareerMatches}>
                      Generate Career Matches
                    </Button>
                  </div>
                </div>
              )}
            </div>
            {careerMatches && careerMatches.length > 0 && (
              <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 rounded-b-lg">
                <Link href="/career-paths" className="text-primary-600 hover:text-primary-800 font-medium flex items-center justify-center">
                  <span>View all career matches</span>
                  <svg className="ml-2 w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                  </svg>
                </Link>
              </div>
            )}
          </div>

          {/* Interview Coach & Resume Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Interview Coach</CardTitle>
                  <CardDescription>
                    Practice your interview skills with AI-powered feedback
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6 bg-slate-50 rounded-lg p-4 border border-slate-200">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium text-slate-900">Scheduled Practice</h3>
                      <Badge variant="outline" className="bg-primary-100 text-primary-800">
                        <CalendarCheck className="mr-1 h-3 w-3" />
                        Tomorrow at 2:00 PM
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-500 mt-1">UX Designer Role - Behavioral Interview</p>
                    <div className="flex items-center mt-3">
                      <Link href="/interview">
                        <Button size="sm">
                          Start Practice
                        </Button>
                      </Link>
                      <Link href="/interview">
                        <Button variant="outline" className="ml-3" size="sm">
                          Reschedule
                        </Button>
                      </Link>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <h3 className="font-medium text-slate-900 mb-3">Interview Types</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <Link href="/interview">
                        <Card className="bg-slate-50 border border-slate-200 transition-all hover:border-primary-300 cursor-pointer card-hover">
                          <CardContent className="p-4">
                            <div className="flex items-start">
                              <div className="flex-shrink-0">
                                <div className="flex items-center justify-center h-10 w-10 rounded-md bg-primary-100 text-primary-600">
                                  <MessageSquare className="h-5 w-5" />
                                </div>
                              </div>
                              <div className="ml-4">
                                <h4 className="text-sm font-medium text-slate-900">Behavioral Interview</h4>
                                <p className="mt-1 text-xs text-slate-500">Practice questions about past experiences and how you handled situations.</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                      
                      <Link href="/interview">
                        <Card className="bg-slate-50 border border-slate-200 transition-all hover:border-primary-300 cursor-pointer card-hover">
                          <CardContent className="p-4">
                            <div className="flex items-start">
                              <div className="flex-shrink-0">
                                <div className="flex items-center justify-center h-10 w-10 rounded-md bg-secondary-100 text-secondary-600">
                                  <Briefcase className="h-5 w-5" />
                                </div>
                              </div>
                              <div className="ml-4">
                                <h4 className="text-sm font-medium text-slate-900">Technical Interview</h4>
                                <p className="mt-1 text-xs text-slate-500">Practice domain-specific questions and problem-solving scenarios.</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-center">
                  <Link href="/interview">
                    <Button>
                      <CalendarCheck className="mr-2 h-4 w-4" />
                      Schedule New Practice
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>

            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Resume Analysis</CardTitle>
                  <CardDescription>AI feedback on your resume</CardDescription>
                </CardHeader>
                <CardContent>
                  {resumesLoading ? (
                    <div className="flex justify-center items-center h-40">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
                    </div>
                  ) : resumes && resumes.length > 0 ? (
                    <>
                      <div className="flex items-center mb-4">
                        <div className="flex-shrink-0">
                          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-yellow-100 text-yellow-600">
                            <FileText className="h-5 w-5" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-md font-medium text-slate-900">{resumes[0].filename}</h3>
                          <p className="text-xs text-slate-500">
                            Uploaded {new Date(resumes[0].uploadedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      
                      {resumes[0].analysis && (
                        <>
                          <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 mb-4">
                            <h4 className="font-medium text-slate-900 mb-2 flex items-center">
                              <AlertTriangle className="text-yellow-500 mr-2 h-4 w-4" />
                              Improvement Areas
                            </h4>
                            <ul className="text-sm text-slate-700 space-y-2">
                              {resumes[0].analysis.improvementAreas.slice(0, 3).map((area, index) => (
                                <li key={index} className="flex items-start">
                                  <AlertCircle className="text-red-500 mt-1 mr-2 h-3 w-3" />
                                  <span>{area}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          
                          <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 mb-4">
                            <h4 className="font-medium text-slate-900 mb-2 flex items-center">
                              <Check className="text-green-500 mr-2 h-4 w-4" />
                              Strengths
                            </h4>
                            <ul className="text-sm text-slate-700 space-y-2">
                              {resumes[0].analysis.strengths.slice(0, 2).map((strength, index) => (
                                <li key={index} className="flex items-start">
                                  <CheckCircle className="text-green-500 mt-1 mr-2 h-3 w-3" />
                                  <span>{strength}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <FileText className="mx-auto h-12 w-12 text-slate-400" />
                      <h3 className="mt-2 text-sm font-medium text-slate-900">No resume uploaded</h3>
                      <p className="mt-1 text-sm text-slate-500">Upload your resume to get AI-powered feedback.</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-center">
                  <Link href="/resume">
                    <Button>
                      <Upload className="mr-2 h-4 w-4" />
                      {resumes && resumes.length > 0 ? "Upload New Version" : "Upload Resume"}
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
          </div>
          
          {/* Skills Development */}
          <div className="mt-8">
            <Card>
              <CardHeader className="border-b border-slate-200">
                <CardTitle>Recommended Skill Development</CardTitle>
                <CardDescription>Suggested learning paths based on your career goals</CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="bg-slate-50 border border-slate-200 transition-all hover:border-primary-300 cursor-pointer card-hover">
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-100 text-primary-600">
                            <Monitor className="h-5 w-5" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="font-medium text-slate-900">Advanced Figma</h3>
                          <p className="mt-1 text-sm text-slate-500">Master component libraries, auto-layout, and design systems</p>
                          <div className="mt-3 flex items-center">
                            <div className="mr-3">
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                15 hours
                              </Badge>
                            </div>
                            <div>
                              <div className="flex items-center">
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-slate-300 h-3 w-3" />
                                <span className="ml-1 text-xs text-slate-500">(432)</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-slate-50 border border-slate-200 transition-all hover:border-primary-300 cursor-pointer card-hover">
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-secondary-100 text-secondary-600">
                            <Users className="h-5 w-5" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="font-medium text-slate-900">User Research Methods</h3>
                          <p className="mt-1 text-sm text-slate-500">Learn effective research techniques for UX design</p>
                          <div className="mt-3 flex items-center">
                            <div className="mr-3">
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                10 hours
                              </Badge>
                            </div>
                            <div>
                              <div className="flex items-center">
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <StarHalf className="text-yellow-400 h-3 w-3" />
                                <span className="ml-1 text-xs text-slate-500">(189)</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-slate-50 border border-slate-200 transition-all hover:border-primary-300 cursor-pointer card-hover">
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <div className="flex items-center justify-center h-12 w-12 rounded-md bg-orange-100 text-orange-500">
                            <Layers className="h-5 w-5" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <h3 className="font-medium text-slate-900">Design Systems</h3>
                          <p className="mt-1 text-sm text-slate-500">Create and maintain scalable design systems</p>
                          <div className="mt-3 flex items-center">
                            <div className="mr-3">
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                12 hours
                              </Badge>
                            </div>
                            <div>
                              <div className="flex items-center">
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <Star className="text-yellow-400 h-3 w-3" />
                                <span className="ml-1 text-xs text-slate-500">(325)</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Link href="/career-paths">
                  <Button>
                    <GraduationCap className="mr-2 h-4 w-4" />
                    View All Learning Paths
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

// Icons
function AlertIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  );
}

function AlertCircleIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}

function CheckIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

function CheckCircleIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}

function UploadIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  );
}

function StarIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  );
}

function StarHalfIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 17.8 5.8 21 7 14.1 2 9.3l7-1L12 2" />
    </svg>
  );
}

function LayersIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polygon points="12 2 2 7 12 12 22 7 12 2" />
      <polyline points="2 17 12 22 22 17" />
      <polyline points="2 12 12 17 22 12" />
    </svg>
  );
}

function MonitorIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
      <line x1="8" y1="21" x2="16" y2="21" />
      <line x1="12" y1="17" x2="12" y2="21" />
    </svg>
  );
}

function UsersIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

function GraduationCapIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
      <path d="M6 12v5c3 3 9 3 12 0v-5" />
    </svg>
  );
}
