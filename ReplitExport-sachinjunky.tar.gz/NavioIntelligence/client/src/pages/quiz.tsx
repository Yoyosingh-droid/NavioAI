import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useLocation } from "wouter";
import {
  BrainCircuit,
  CheckCircle2,
  Clock,
  Loader2,
  PersonStanding,
  Rocket,
  ChevronRight,
  BriefcaseIcon,
  BuildingIcon,
  UserIcon,
  PuzzleIcon,
  Sparkles
} from "lucide-react";

// Personality quiz schema
const quizResponseSchema = z.object({
  responses: z.record(z.string()),
});

// Quiz questions
const quizQuestions = [
  {
    id: "workStyle",
    question: "How do you prefer to work?",
    options: [
      { value: "independent", label: "Independently with minimal oversight" },
      { value: "collaborative", label: "Collaboratively in a team environment" },
      { value: "mixed", label: "A mix of independent and team work" },
      { value: "leadership", label: "Leading a team toward common goals" },
    ],
  },
  {
    id: "problemSolving",
    question: "When faced with a complex problem, you typically:",
    options: [
      { value: "analytical", label: "Break it down systematically and analyze each component" },
      { value: "creative", label: "Look for creative, outside-the-box solutions" },
      { value: "intuitive", label: "Trust your intuition and past experience" },
      { value: "collaborative", label: "Consult with others to get different perspectives" },
    ],
  },
  {
    id: "communication",
    question: "How would you describe your communication style?",
    options: [
      { value: "direct", label: "Direct and straightforward" },
      { value: "diplomatic", label: "Diplomatic and considerate" },
      { value: "detailed", label: "Detailed and thorough" },
      { value: "visual", label: "Visual and expressive" },
    ],
  },
  {
    id: "feedback",
    question: "How do you prefer to receive feedback?",
    options: [
      { value: "direct", label: "Direct and immediate" },
      { value: "structured", label: "Structured with specific examples" },
      { value: "balanced", label: "Balanced with positives and areas for improvement" },
      { value: "private", label: "Privately in a one-on-one setting" },
    ],
  },
  {
    id: "pressure",
    question: "How do you respond to pressure or tight deadlines?",
    options: [
      { value: "thrive", label: "Thrive under pressure and increased focus" },
      { value: "methodical", label: "Become more methodical and structured" },
      { value: "delegate", label: "Delegate tasks and collaborate more" },
      { value: "stress", label: "Feel stressed but push through with determination" },
    ],
  },
  {
    id: "learning",
    question: "How do you prefer to learn new skills?",
    options: [
      { value: "handson", label: "Hands-on practice and experimentation" },
      { value: "theoretical", label: "Reading and theoretical understanding first" },
      { value: "mentorship", label: "Through mentorship and guidance" },
      { value: "structured", label: "Structured courses and formal education" },
    ],
  },
  {
    id: "change",
    question: "How do you feel about change in the workplace?",
    options: [
      { value: "embrace", label: "Embrace it as an opportunity for growth" },
      { value: "cautious", label: "Cautiously evaluate its benefits and drawbacks" },
      { value: "resist", label: "Initially resistant but adapt over time" },
      { value: "lead", label: "Actively lead and implement change" },
    ],
  },
  {
    id: "idealEnvironment",
    question: "What type of work environment helps you perform best?",
    options: [
      { value: "quiet", label: "Quiet and focused with minimal distractions" },
      { value: "dynamic", label: "Dynamic and energetic with lots of interaction" },
      { value: "flexible", label: "Flexible with the option to change settings" },
      { value: "structured", label: "Structured with clear expectations" },
    ],
  },
  {
    id: "motivation",
    question: "What motivates you most in your career?",
    options: [
      { value: "impact", label: "Making a meaningful impact" },
      { value: "growth", label: "Learning and personal growth" },
      { value: "recognition", label: "Recognition and advancement" },
      { value: "balance", label: "Work-life balance and stability" },
    ],
  },
  {
    id: "decision",
    question: "How do you typically make important decisions?",
    options: [
      { value: "data", label: "Based on data and logical analysis" },
      { value: "values", label: "Based on personal values and principles" },
      { value: "gut", label: "Trusting my gut feeling and intuition" },
      { value: "counsel", label: "Seeking counsel from trusted advisors" },
    ],
  },
];

export default function Quiz() {
  const [step, setStep] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [quizResults, setQuizResults] = useState<any>(null);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch existing profile data
  const { data: profileData, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/profile'],
    queryFn: undefined, // Use the default fetcher
  });

  // Setup form with validation
  const form = useForm<z.infer<typeof quizResponseSchema>>({
    resolver: zodResolver(quizResponseSchema),
    defaultValues: {
      responses: {},
    },
  });

  // Submit quiz responses
  const submitQuizMutation = useMutation({
    mutationFn: async (responses: any) => {
      const res = await apiRequest("POST", "/api/personality-quiz", { responses });
      return await res.json();
    },
    onSuccess: (data) => {
      setQuizResults(data);
      setQuizCompleted(true);
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      toast({
        title: "Quiz completed!",
        description: "Your personality profile has been analyzed",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to analyze quiz",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Check if quiz has already been taken
  const quizAlreadyTaken = profileData?.personalityResult && Object.keys(profileData.personalityResult).length > 0;

  // Current question
  const currentQuestion = quizQuestions[step];

  // Next or Submit
  const handleNext = () => {
    const currentResponse = form.getValues().responses[currentQuestion.id];
    if (!currentResponse) {
      toast({
        title: "Please select an option",
        description: "You need to select an answer before continuing",
        variant: "destructive",
      });
      return;
    }

    if (step < quizQuestions.length - 1) {
      setStep(step + 1);
    } else {
      // Submit quiz responses
      submitQuizMutation.mutate(form.getValues());
    }
  };

  // Previous button handler
  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  // Restart quiz
  const handleRestartQuiz = () => {
    form.reset({ responses: {} });
    setStep(0);
    setQuizCompleted(false);
    setQuizResults(null);
  };

  // View career matches
  const handleViewCareerMatches = () => {
    navigate("/career-paths");
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      
      <div className="flex flex-1">
        <Sidebar className="hidden md:block" />
        
        <main className="flex-1 p-6">
          <div className="max-w-3xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Personality Quiz</h1>
                <p className="text-sm text-slate-500 mt-1">
                  Discover your professional personality traits and ideal career paths
                </p>
              </div>
            </div>
            
            {quizAlreadyTaken && !quizCompleted && !profileLoading ? (
              <Card>
                <CardHeader>
                  <CardTitle>Quiz Already Completed</CardTitle>
                  <CardDescription>
                    You've already taken the personality quiz. Would you like to review your results or take it again?
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center p-6">
                  <div className="rounded-full bg-primary-100 p-4 mb-4">
                    <CheckCircle2 className="h-8 w-8 text-primary-600" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-2">Your Personality Type: {profileData.personalityResult.personalityType}</h3>
                  <p className="text-slate-500 mb-6 text-center">
                    You completed this quiz on {new Date(profileData.personalityResult.completedAt || Date.now()).toLocaleDateString()}. 
                    Your results are being used to match you with ideal career paths.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Button onClick={() => navigate("/career-paths")}>
                      View Career Matches
                    </Button>
                    <Button variant="outline" onClick={handleRestartQuiz}>
                      Take Quiz Again
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : quizCompleted ? (
              <Card>
                <CardHeader>
                  <CardTitle>Your Personality Results</CardTitle>
                  <CardDescription>
                    Based on your responses, here's what we've discovered about your professional personality
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-primary-50 p-6 rounded-lg border border-primary-100">
                    <div className="flex items-center mb-4">
                      <div className="bg-primary-100 p-2 rounded-full mr-3">
                        <PersonStanding className="h-6 w-6 text-primary-700" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-slate-900">{quizResults.personalityType}</h3>
                        <p className="text-sm text-slate-500">Your Professional Personality Type</p>
                      </div>
                    </div>
                    <Separator className="my-4" />
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-sm text-slate-700 mb-2">Key Strengths</h4>
                        <div className="flex flex-wrap gap-2">
                          {quizResults.strengths.map((strength: string, index: number) => (
                            <Badge key={index} variant="secondary" className="bg-primary-100 text-primary-800">
                              {strength}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium text-sm text-slate-700 mb-2">Work Style</h4>
                        <p className="text-slate-600 text-sm">{quizResults.workStyle}</p>
                      </div>
                      
                      <div>
                        <h4 className="font-medium text-sm text-slate-700 mb-2">Ideal Work Environment</h4>
                        <p className="text-slate-600 text-sm">{quizResults.idealEnvironment}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
                    <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center">
                      <Sparkles className="h-5 w-5 mr-2 text-amber-500" /> 
                      Recommended Career Paths
                    </h3>
                    <div className="space-y-3">
                      {quizResults.careerSuggestions.map((career: string, index: number) => (
                        <div key={index} className="flex items-start">
                          <div className="bg-slate-200 p-1 rounded-full mr-3 mt-0.5">
                            <ChevronRight className="h-4 w-4 text-slate-600" />
                          </div>
                          <span className="text-slate-800">{career}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={handleRestartQuiz}>
                    Take Quiz Again
                  </Button>
                  <Button onClick={handleViewCareerMatches}>
                    View Career Matches
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Career Personality Quiz</CardTitle>
                  <CardDescription>
                    Answer 10 quick questions to discover your ideal career paths
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <div className="flex justify-between text-sm text-slate-500 mb-2">
                      <span>Question {step + 1} of {quizQuestions.length}</span>
                      <span>{Math.round(((step) / quizQuestions.length) * 100)}% complete</span>
                    </div>
                    <Progress value={((step) / quizQuestions.length) * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-8">
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium flex items-center">
                        <BrainCircuit className="text-primary-600 mr-2 h-5 w-5" />
                        {currentQuestion.question}
                      </h3>
                      
                      <RadioGroup
                        value={form.watch(`responses.${currentQuestion.id}`)}
                        onValueChange={(value) => form.setValue(`responses.${currentQuestion.id}`, value)}
                        className="mt-4 space-y-3"
                      >
                        {currentQuestion.options.map((option) => (
                          <div key={option.value} className="flex items-start space-x-2 border p-3 rounded-md hover:bg-slate-50 cursor-pointer">
                            <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                            <Label htmlFor={option.value} className="font-normal cursor-pointer flex-1">
                              {option.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={handlePrevious}
                    disabled={step === 0}
                  >
                    Previous
                  </Button>
                  
                  <Button 
                    onClick={handleNext}
                    disabled={!form.watch(`responses.${currentQuestion.id}`) || submitQuizMutation.isPending}
                  >
                    {step === quizQuestions.length - 1 ? (
                      submitQuizMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Analyzing
                        </>
                      ) : (
                        "Submit"
                      )
                    ) : (
                      "Next"
                    )}
                  </Button>
                </CardFooter>
              </Card>
            )}
            
            {!quizCompleted && !quizAlreadyTaken && (
              <Card className="mt-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Rocket className="h-5 w-5 mr-2 text-primary-500" />
                    Why Take This Quiz?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                      <div className="flex items-center mb-2">
                        <BriefcaseIcon className="h-5 w-5 text-primary-600 mr-2" />
                        <h3 className="font-medium">Personalized Career Matches</h3>
                      </div>
                      <p className="text-sm text-slate-600">Discover career paths that align with your unique personality traits and working style.</p>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                      <div className="flex items-center mb-2">
                        <BuildingIcon className="h-5 w-5 text-secondary-500 mr-2" />
                        <h3 className="font-medium">Ideal Work Environment</h3>
                      </div>
                      <p className="text-sm text-slate-600">Learn which workplace cultures and environments help you thrive professionally.</p>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                      <div className="flex items-center mb-2">
                        <UserIcon className="h-5 w-5 text-orange-500 mr-2" />
                        <h3 className="font-medium">Strengths & Blind Spots</h3>
                      </div>
                      <p className="text-sm text-slate-600">Identify your natural strengths and potential areas for growth in professional settings.</p>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                      <div className="flex items-center mb-2">
                        <PuzzleIcon className="h-5 w-5 text-green-600 mr-2" />
                        <h3 className="font-medium">Team Compatibility</h3>
                      </div>
                      <p className="text-sm text-slate-600">Understand how you collaborate best with others and your role in team dynamics.</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="w-full text-center">
                    <p className="text-sm text-slate-500 mb-2 flex items-center justify-center">
                      <Clock className="h-4 w-4 mr-1" />
                      Takes approximately 5 minutes to complete
                    </p>
                  </div>
                </CardFooter>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
