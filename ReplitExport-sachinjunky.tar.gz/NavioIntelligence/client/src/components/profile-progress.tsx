import { Progress } from "@/components/ui/progress";
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";

interface ProgressItem {
  icon: JSX.Element;
  title: string;
  value: number;
  description?: string;
  color: string;
}

interface ProfileProgressProps {
  items: ProgressItem[];
}

export default function ProfileProgress({ items }: ProfileProgressProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Career Journey</CardTitle>
        <CardDescription>Track your progress and complete the next steps</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, index) => (
            <div key={index} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
              <div className="flex items-center">
                <div className={`flex items-center justify-center h-12 w-12 rounded-md ${item.color} text-white`}>
                  {item.icon}
                </div>
                <div className="ml-4">
                  <h3 className="text-sm font-medium text-slate-900">{item.title}</h3>
                  <div className="mt-1">
                    <div className="relative pt-1">
                      <div className="overflow-hidden h-2 text-xs flex rounded bg-slate-200">
                        <div 
                          style={{ width: `${item.value}%` }} 
                          className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center ${
                            item.value < 50 ? "bg-amber-500" : item.value < 80 ? "bg-blue-500" : "bg-green-500"
                          }`}
                        ></div>
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span className="text-slate-500">{item.value}%</span>
                        {item.description && (
                          <span className={`${
                            item.value < 50 ? "text-amber-600" : item.value < 80 ? "text-blue-600" : "text-green-600"
                          } font-medium`}>
                            {item.description}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
