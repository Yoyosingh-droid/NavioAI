import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MonitorIcon, Users, Layers, StarIcon, GraduationCap } from "lucide-react";

interface SkillCourse {
  id: string;
  title: string;
  description: string;
  duration: string;
  rating: number;
  reviews: number;
  icon: React.ReactNode;
  color: string;
}

interface SkillsDevelopmentProps {
  title?: string;
  description?: string;
  courses?: SkillCourse[];
}

export default function SkillsDevelopment({
  title = "Recommended Skill Development",
  description = "Suggested learning paths based on your career goals",
  courses = defaultCourses,
}: SkillsDevelopmentProps) {
  return (
    <Card>
      <CardHeader className="border-b border-slate-200">
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card 
              key={course.id} 
              className="bg-slate-50 border border-slate-200 transition-all hover:border-primary-300 cursor-pointer card-hover"
            >
              <CardContent className="p-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <div className={`flex items-center justify-center h-12 w-12 rounded-md ${course.color} mr-4`}>
                      {course.icon}
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-slate-900">{course.title}</h3>
                    <p className="mt-1 text-sm text-slate-500">{course.description}</p>
                    <div className="mt-3 flex items-center">
                      <div className="mr-3">
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                          {course.duration}
                        </Badge>
                      </div>
                      <div>
                        <div className="flex items-center">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <StarIcon 
                              key={i}
                              className={`h-3 w-3 ${i < course.rating ? "text-yellow-400" : "text-slate-300"}`}
                            />
                          ))}
                          <span className="ml-1 text-xs text-slate-500">({course.reviews})</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button>
          <GraduationCap className="mr-2 h-4 w-4" />
          View All Learning Paths
        </Button>
      </CardFooter>
    </Card>
  );
}

// Default courses
const defaultCourses: SkillCourse[] = [
  {
    id: "1",
    title: "Advanced Figma",
    description: "Master component libraries, auto-layout, and design systems",
    duration: "15 hours",
    rating: 4,
    reviews: 432,
    icon: <MonitorIcon className="h-5 w-5" />,
    color: "bg-primary-100 text-primary-600"
  },
  {
    id: "2",
    title: "User Research Methods",
    description: "Learn effective research techniques for UX design",
    duration: "10 hours",
    rating: 4.5,
    reviews: 189,
    icon: <Users className="h-5 w-5" />,
    color: "bg-secondary-100 text-secondary-600"
  },
  {
    id: "3",
    title: "Design Systems",
    description: "Create and maintain scalable design systems",
    duration: "12 hours",
    rating: 5,
    reviews: 325,
    icon: <Layers className="h-5 w-5" />,
    color: "bg-accent-100 text-accent-500"
  }
];

// Star icon component
function StarIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="currentColor"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  );
}
