import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home,
  Briefcase,
  FileText,
  MessageSquare,
  User,
  BookOpen,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const sidebarItems = [
    { icon: Home, label: "Dashboard", href: "/" },
    { icon: Briefcase, label: "Career Paths", href: "/career-paths" },
    { icon: FileText, label: "Resume Analysis", href: "/resume" },
    { icon: MessageSquare, label: "Interview Coach", href: "/interview" },
    { icon: BookOpen, label: "Personality Quiz", href: "/quiz" },
    { icon: User, label: "Profile", href: "/profile" },
  ];

  return (
    <div
      className={cn(
        "flex flex-col border-r border-border transition-all duration-300 bg-sidebar",
        collapsed ? "w-20" : "w-64",
        className
      )}
    >
      <div className="p-4 flex items-center justify-between">
        {!collapsed && (
          <div className="flex items-center">
            <span className="font-semibold text-lg text-sidebar-foreground">Navigation</span>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="ml-auto"
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? (
            <ChevronRight className="h-5 w-5" />
          ) : (
            <ChevronLeft className="h-5 w-5" />
          )}
          <span className="sr-only">
            {collapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          </span>
        </Button>
      </div>
      <nav className="flex-1">
        <ul className="space-y-1 p-2">
          {sidebarItems.map((item) => (
            <li key={item.href}>
              <Link href={item.href}>
                <a
                  className={cn(
                    "flex items-center py-2 px-3 rounded-md group transition-colors",
                    location === item.href
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                  )}
                >
                  <item.icon
                    className={cn(
                      "h-5 w-5 shrink-0",
                      collapsed ? "mx-auto" : "mr-3"
                    )}
                  />
                  {!collapsed && <span>{item.label}</span>}
                  {collapsed && (
                    <span className="sr-only">{item.label}</span>
                  )}
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
