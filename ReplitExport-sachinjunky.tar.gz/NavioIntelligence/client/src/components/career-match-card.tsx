import { useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bookmark, BookmarkCheck, ChevronDown, ChevronUp, Info } from "lucide-react";
import PandumpsChart from "./pandumps-chart";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SkillMatch {
  [key: string]: number;
}

interface CareerMatch {
  id: number;
  careerPathId: number;
  matchScore: number;
  skillsMatch: SkillMatch;
  gapAnalysis?: string[];
  isSaved: boolean;
  careerPath: {
    id: number;
    title: string;
    description: string;
    skillsRequired: SkillMatch;
    avgSalary: string;
    hiringTrend: string;
    yoyGrowth: string;
    jobListings: string;
    pandumpsScore: {
      current: number;
      history: number[];
    };
  };
}

interface CareerMatchCardProps {
  careerMatch: CareerMatch;
}

export default function CareerMatchCard({ careerMatch }: CareerMatchCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [savePending, setSavePending] = useState(false);
  const { toast } = useToast();

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  const toggleSave = async () => {
    try {
      setSavePending(true);
      await apiRequest(
        "POST", 
        `/api/career-matches/${careerMatch.careerPathId}/toggle-save`
      );
      
      // Invalidate queries to refresh career matches
      queryClient.invalidateQueries({ queryKey: ['/api/career-matches'] });
      
      toast({
        title: careerMatch.isSaved ? "Removed from saved" : "Saved to favorites",
        description: careerMatch.isSaved 
          ? `${careerMatch.careerPath.title} removed from your saved matches.` 
          : `${careerMatch.careerPath.title} added to your saved matches.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update saved status",
        variant: "destructive",
      });
    } finally {
      setSavePending(false);
    }
  };

  return (
    <Card className="mb-8">
      <CardHeader className="pb-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <CardTitle className="text-xl font-semibold text-slate-900">
              {careerMatch.careerPath.title}
            </CardTitle>
            <CardDescription className="mt-1">
              {careerMatch.careerPath.description}
            </CardDescription>
          </div>
          <div className="mt-2 sm:mt-0 flex items-center">
            <div className="flex items-center">
              <span className="text-sm font-medium text-slate-700 mr-2">Pandumps Score:</span>
              <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">
                <ChartIcon className="mr-1 h-3 w-3" />
                {careerMatch.careerPath.pandumpsScore.current}/8
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pb-2">
        <div className={`grid grid-cols-1 ${expanded ? 'lg:grid-cols-3' : 'lg:grid-cols-2'} gap-6`}>
          <div className={`${expanded ? 'col-span-2' : 'col-span-1'}`}>
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
              <h4 className="font-medium text-slate-900 mb-3">Skills Match</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {Object.entries(careerMatch.skillsMatch).slice(0, 4).map(([skill, percentage]) => (
                  <div key={skill}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-slate-700">{skill}</span>
                      <span 
                        className={`text-sm font-medium ${
                          percentage >= 80 ? 'text-green-600' : 
                          percentage >= 60 ? 'text-yellow-600' : 
                          'text-red-600'
                        }`}
                      >
                        {percentage}%
                      </span>
                    </div>
                    <Progress 
                      value={percentage} 
                      className={`h-2 ${
                        percentage >= 80 ? 'bg-green-200' : 
                        percentage >= 60 ? 'bg-yellow-200' : 
                        'bg-red-200'
                      }`}
                      indicatorClassName={`${
                        percentage >= 80 ? 'bg-green-500' : 
                        percentage >= 60 ? 'bg-yellow-500' : 
                        'bg-red-500'
                      }`}
                    />
                  </div>
                ))}
              </div>
              
              {careerMatch.gapAnalysis && careerMatch.gapAnalysis.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-medium text-slate-900 mb-2">Gap Analysis</h4>
                  <div className="flex flex-wrap gap-2">
                    {careerMatch.gapAnalysis.map((gap, index) => (
                      <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                        <PlusIcon className="mr-1 h-3 w-3" />
                        {gap}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="col-span-1">
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 h-full">
              <h4 className="font-medium text-slate-900 mb-3">Market Outlook</h4>
              <div className="mb-4">
                <PandumpsChart data={careerMatch.careerPath.pandumpsScore} />
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                <div className="bg-white rounded-md p-2 border border-slate-200">
                  <span className="text-xs text-slate-500">Hiring Trend</span>
                  <div className="flex items-center">
                    <TrendingUpIcon className="text-green-500 mr-1 h-3 w-3" />
                    <span className="text-sm font-medium">{careerMatch.careerPath.hiringTrend}</span>
                  </div>
                </div>
                <div className="bg-white rounded-md p-2 border border-slate-200">
                  <span className="text-xs text-slate-500">Avg. Salary</span>
                  <div className="text-sm font-medium">{careerMatch.careerPath.avgSalary}</div>
                </div>
                <div className="bg-white rounded-md p-2 border border-slate-200">
                  <span className="text-xs text-slate-500">YoY Growth</span>
                  <div className="flex items-center">
                    <TrendingUpIcon className="text-green-500 mr-1 h-3 w-3" />
                    <span className="text-sm font-medium">{careerMatch.careerPath.yoyGrowth}</span>
                  </div>
                </div>
                <div className="bg-white rounded-md p-2 border border-slate-200">
                  <span className="text-xs text-slate-500">Job Listings</span>
                  <div className="text-sm font-medium">{careerMatch.careerPath.jobListings}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex flex-col sm:flex-row sm:justify-between pt-4 gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleExpanded}
          className="w-full sm:w-auto"
        >
          {expanded ? (
            <>
              <ChevronUp className="mr-2 h-4 w-4" />
              Show Less
            </>
          ) : (
            <>
              <ChevronDown className="mr-2 h-4 w-4" />
              Show More
            </>
          )}
        </Button>
        
        <div className="flex gap-2 w-full sm:w-auto">
          <Button
            variant="outline"
            size="sm"
            className="w-full sm:w-auto"
            onClick={toggleSave}
            disabled={savePending}
          >
            {careerMatch.isSaved ? (
              <>
                <BookmarkCheck className="mr-2 h-4 w-4" />
                Saved
              </>
            ) : (
              <>
                <Bookmark className="mr-2 h-4 w-4" />
                Save
              </>
            )}
          </Button>
          
          <Button 
            variant="default" 
            size="sm"
            className="w-full sm:w-auto"
          >
            <Info className="mr-2 h-4 w-4" />
            Explore Details
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}

function ChartIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 3v18h18" />
      <path d="m19 9-5 5-4-4-3 3" />
    </svg>
  );
}

function TrendingUpIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
      <polyline points="17 6 23 6 23 12" />
    </svg>
  );
}

function PlusIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" x2="12" y1="8" y2="16" />
      <line x1="8" x2="16" y1="12" y2="12" />
    </svg>
  );
}
