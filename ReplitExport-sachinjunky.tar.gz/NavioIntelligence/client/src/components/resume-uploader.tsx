import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadCloud, File, AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";

export default function ResumeUploader() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    setError(null);
    
    if (!selectedFile) return;
    
    // Validate file type
    const fileType = selectedFile.type;
    if (fileType !== 'application/pdf' && 
        fileType !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      setError('Please upload a PDF or DOCX file');
      setFile(null);
      return;
    }
    
    // Validate file size (5MB max)
    if (selectedFile.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      setFile(null);
      return;
    }
    
    setFile(selectedFile);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    
    setError(null);
    
    // Validate file type
    const fileType = droppedFile.type;
    if (fileType !== 'application/pdf' && 
        fileType !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      setError('Please upload a PDF or DOCX file');
      return;
    }
    
    // Validate file size (5MB max)
    if (droppedFile.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      return;
    }
    
    setFile(droppedFile);
  };

  const uploadResume = async () => {
    if (!file) return;
    
    try {
      setUploading(true);
      setProgress(10);
      
      const formData = new FormData();
      formData.append('resume', file);
      
      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + Math.floor(Math.random() * 10);
          return newProgress > 90 ? 90 : newProgress;
        });
      }, 300);
      
      const response = await fetch('/api/resume/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      clearInterval(progressInterval);
      
      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to upload resume');
      }
      
      setProgress(100);
      
      const resumeData = await response.json();
      
      // Invalidate queries to refresh resume list
      queryClient.invalidateQueries({ queryKey: ['/api/resume/list'] });
      
      toast({
        title: "Resume uploaded successfully",
        description: "Your resume has been analyzed. Check the analysis for details.",
        variant: "default",
      });
      
      // Reset state after successful upload
      setTimeout(() => {
        setFile(null);
        setProgress(0);
        setUploading(false);
      }, 1000);
      
    } catch (err) {
      setError(err.message);
      setUploading(false);
      setProgress(0);
      
      toast({
        title: "Upload failed",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Your Resume</CardTitle>
        <CardDescription>
          Upload your resume in PDF or DOCX format for AI analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <input
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept=".pdf,.docx"
          onChange={handleFileChange}
        />
        
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
            error ? 'border-red-300 bg-red-50' : 'border-slate-300 hover:border-primary-300 hover:bg-slate-50'
          }`}
          onClick={triggerFileInput}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {uploading ? (
            <div className="flex flex-col items-center space-y-4">
              <Loader2 className="h-10 w-10 text-primary-500 animate-spin" />
              <p className="text-slate-600">Uploading and analyzing your resume...</p>
              <Progress value={progress} className="w-full max-w-xs" />
            </div>
          ) : file ? (
            <div className="flex flex-col items-center space-y-4">
              <CheckCircle2 className="h-10 w-10 text-green-500" />
              <p className="text-slate-600">
                <span className="font-semibold">{file.name}</span>
                <span className="text-sm text-slate-500 block">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </span>
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-4">
              {error ? (
                <AlertCircle className="h-10 w-10 text-red-500" />
              ) : (
                <UploadCloud className="h-10 w-10 text-slate-400" />
              )}
              <div>
                <p className="text-slate-600 font-medium">
                  {error || 'Drag and drop your resume here or click to browse'}
                </p>
                <p className="text-sm text-slate-500 mt-1">
                  Supports PDF and DOCX files up to 5MB
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button 
          onClick={uploadResume} 
          disabled={!file || uploading}
          className="w-full sm:w-auto"
        >
          {uploading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Analyzing
            </>
          ) : (
            <>
              <UploadCloud className="mr-2 h-4 w-4" />
              Upload & Analyze
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
