import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Mic, MicOff, Play, SkipForward, Pause, Send, MessageCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Question {
  question: string;
  context: string;
}

interface InterviewSimulatorProps {
  careerPath: string;
  interviewType: string;
  sessionId?: number;
}

export default function InterviewSimulator({ 
  careerPath, 
  interviewType,
  sessionId 
}: InterviewSimulatorProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [timePassed, setTimePassed] = useState(0);
  const [feedback, setFeedback] = useState<any>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Fetch interview questions
  useEffect(() => {
    async function fetchQuestions() {
      try {
        setIsLoading(true);
        const response = await fetch(
          `/api/interview-questions?careerPath=${encodeURIComponent(careerPath)}&interviewType=${encodeURIComponent(interviewType)}`,
          { credentials: 'include' }
        );
        
        if (!response.ok) {
          throw new Error("Failed to fetch interview questions");
        }
        
        const data = await response.json();
        setQuestions(data.questions);
      } catch (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchQuestions();
  }, [careerPath, interviewType, toast]);

  // Timer functionality
  useEffect(() => {
    if (isRecording) {
      timerRef.current = setInterval(() => {
        setTimePassed(prev => prev + 1);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRecording]);

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      setTimePassed(0);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setAnswer("");
      setFeedback(null);
      setTimePassed(0);
      if (isRecording) {
        setIsRecording(false);
      }
    }
  };

  const evaluateAnswer = async () => {
    if (!answer.trim()) {
      toast({
        title: "Empty answer",
        description: "Please provide an answer before submitting",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsEvaluating(true);
      const response = await apiRequest("POST", "/api/evaluate-answer", {
        question: questions[currentQuestionIndex].question,
        answer,
        careerPath
      });
      
      const evaluationData = await response.json();
      setFeedback(evaluationData);
      
      // Stop recording if it's still active
      if (isRecording) {
        setIsRecording(false);
      }
      
    } catch (error) {
      toast({
        title: "Evaluation failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsEvaluating(false);
    }
  };

  const completeSession = async () => {
    if (!sessionId) return;
    
    try {
      await apiRequest("POST", `/api/interview-sessions/${sessionId}/complete`, {
        feedback: {
          questionsAnswered: currentQuestionIndex + 1,
          totalQuestions: questions.length,
          averageScore: feedback ? feedback.score : 0
        }
      });
      
      toast({
        title: "Session completed",
        description: "Your interview practice session has been saved",
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save session data",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-10">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mb-4"></div>
            <p className="text-slate-600">Loading interview questions...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (questions.length === 0) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-10">
            <AlertCircle className="h-10 w-10 text-amber-500 mb-4" />
            <p className="text-slate-600">No questions available. Try a different career path or interview type.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>{interviewType} Interview</CardTitle>
            <CardDescription>
              For {careerPath} position - Question {currentQuestionIndex + 1} of {questions.length}
            </CardDescription>
          </div>
          <Badge variant="outline" className="ml-auto">
            {formatTime(timePassed)}
          </Badge>
        </div>
        <Progress 
          value={(currentQuestionIndex / questions.length) * 100} 
          className="h-2 mt-2"
        />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <p className="text-lg font-medium mb-2">{questions[currentQuestionIndex]?.question}</p>
          <p className="text-sm text-slate-500">{questions[currentQuestionIndex]?.context}</p>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <p className="text-sm font-medium">Your Answer</p>
            <Button 
              variant={isRecording ? "destructive" : "outline"} 
              size="sm"
              onClick={toggleRecording}
              disabled={!!feedback}
            >
              {isRecording ? (
                <>
                  <MicOff className="h-4 w-4 mr-2" />
                  Stop Recording
                </>
              ) : (
                <>
                  <Mic className="h-4 w-4 mr-2" />
                  Start Recording
                </>
              )}
            </Button>
          </div>
          <Textarea
            placeholder="Type your answer here..."
            className="min-h-[120px]"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            disabled={isEvaluating || !!feedback}
          />
        </div>
        
        {feedback && (
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-slate-900">Feedback</h3>
                <Badge className={
                  feedback.score >= 8 ? "bg-green-100 text-green-800" :
                  feedback.score >= 5 ? "bg-amber-100 text-amber-800" :
                  "bg-red-100 text-red-800"
                }>
                  Score: {feedback.score}/10
                </Badge>
              </div>
              
              <div className="space-y-3">
                <div>
                  <h4 className="text-sm font-medium text-green-600 mb-1">Strengths</h4>
                  <ul className="text-sm space-y-1">
                    {feedback.strengths.map((strength: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <CheckIcon className="h-4 w-4 text-green-500 mr-2 mt-0.5" />
                        <span>{strength}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-amber-600 mb-1">Areas for Improvement</h4>
                  <ul className="text-sm space-y-1">
                    {feedback.improvements.map((improvement: string, idx: number) => (
                      <li key={idx} className="flex items-start">
                        <AlertTriangleIcon className="h-4 w-4 text-amber-500 mr-2 mt-0.5" />
                        <span>{improvement}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-blue-600 mb-1">Alternative Response</h4>
                  <div className="bg-blue-50 p-3 rounded-md text-sm border border-blue-100">
                    <MessageCircle className="h-4 w-4 text-blue-500 inline mr-2" />
                    {feedback.alternativeResponse}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          {currentQuestionIndex === questions.length - 1 && feedback && (
            <Button variant="default" onClick={completeSession}>
              Complete Session
            </Button>
          )}
        </div>
        <div className="flex space-x-2">
          {!feedback ? (
            <Button 
              onClick={evaluateAnswer} 
              disabled={!answer.trim() || isEvaluating}
            >
              {isEvaluating ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Evaluating...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Submit Answer
                </>
              )}
            </Button>
          ) : (
            <Button 
              variant="default" 
              onClick={nextQuestion}
              disabled={currentQuestionIndex >= questions.length - 1}
            >
              {currentQuestionIndex >= questions.length - 1 ? (
                "Last Question"
              ) : (
                <>
                  <SkipForward className="h-4 w-4 mr-2" />
                  Next Question
                </>
              )}
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}

function CheckIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

function AlertTriangleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </svg>
  );
}
