import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import CareerPaths from "@/pages/career-paths";
import ResumeAnalysis from "@/pages/resume-analysis";
import InterviewCoach from "@/pages/interview-coach";
import Profile from "@/pages/profile";
import Quiz from "@/pages/quiz";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "@/hooks/use-auth";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

function App() {
  // Create a client for react-query
  const queryClient = new QueryClient();
  
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Switch>
          <Route path="/auth" component={AuthPage} />
          {/* Quiz should be accessible without profile check */}
          <ProtectedRoute path="/quiz" component={Quiz} />
          <ProtectedRoute path="/profile" component={Profile} />
          
          {/* These routes require logged in users */}
          <ProtectedRoute path="/" component={Dashboard} />
          <ProtectedRoute path="/career-paths" component={CareerPaths} />
          <ProtectedRoute path="/resume" component={ResumeAnalysis} />
          <ProtectedRoute path="/interview" component={InterviewCoach} />
          
          <Route component={NotFound} />
        </Switch>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
